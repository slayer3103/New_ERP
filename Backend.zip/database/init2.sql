
-- Standardized ERP Seed Data
SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION';

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','superadmin') DEFAULT 'admin',
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `status`, `created_at`) VALUES
(1, 'admin', '$2b$10$glRJI0l/694HauqYf0V4sOlXMAGT9MgVrAMpvwkZTo3/ockHsJfy6', 'admin', 'Active', '2026-06-07 18:06:04'),
(3, 'superadmin', '$2b$10$Sr.IihsiZGWxa.AUtSNehuO7uzJ0Axnj8LSopm4vBU1KXPBLorzH2', 'superadmin', 'Active', '2026-06-07 18:10:14');

-- --------------------------------------------------------



-- --------------------------------------------------------
-- Table structure for table `counters`
-- --------------------------------------------------------
CREATE TABLE `counters` (
  `id` varchar(50) NOT NULL,
  `seq` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `counters` (`id`, `seq`) VALUES
('invoice_2025-26', 10),
('purchaseorder_2025-26', 8),
('quotation_2025-26', 6),
('workorder_2025-26', 6);

-- --------------------------------------------------------
-- Table structure for table `customers`
-- --------------------------------------------------------
CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `customer_type` enum('Domestic','International') NOT NULL DEFAULT 'Domestic',
  `title` enum('MR','MS','MRS','DR') DEFAULT 'MR',
  `customer_name` varchar(100) NOT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `office_no` varchar(15) DEFAULT NULL,
  `pan` varchar(20) DEFAULT NULL,
  `gst` varchar(30) DEFAULT NULL,
  `currency` varchar(10) DEFAULT 'INR',
  `document_path` varchar(255) DEFAULT NULL,
  `billing_recipient_name` varchar(100) DEFAULT NULL,
  `billing_country` varchar(50) DEFAULT NULL,
  `billing_address1` text DEFAULT NULL,
  `billing_address2` text DEFAULT NULL,
  `billing_city` varchar(50) DEFAULT NULL,
  `billing_state` varchar(50) DEFAULT NULL,
  `billing_state_code` varchar(10) DEFAULT NULL COMMENT 'State code for billing address (e.g., 27 for Maharashtra)',
  `billing_pincode` varchar(10) DEFAULT NULL,
  `billing_fax` varchar(20) DEFAULT NULL,
  `billing_phone` varchar(20) DEFAULT NULL,
  `shipping_recipient_name` varchar(100) DEFAULT NULL,
  `shipping_country` varchar(50) DEFAULT NULL,
  `shipping_address1` text DEFAULT NULL,
  `shipping_address2` text DEFAULT NULL,
  `shipping_city` varchar(50) DEFAULT NULL,
  `shipping_state` varchar(50) DEFAULT NULL,
  `shipping_state_code` varchar(10) DEFAULT NULL COMMENT 'State code for shipping address (e.g., 27 for Maharashtra)',
  `shipping_pincode` varchar(10) DEFAULT NULL,
  `shipping_fax` varchar(20) DEFAULT NULL,
  `shipping_phone` varchar(20) DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `customers` (`id`, `customer_type`, `title`, `customer_name`, `company_name`, `display_name`, `email`, `mobile`, `office_no`, `pan`, `gst`, `currency`, `document_path`, `billing_recipient_name`, `billing_country`, `billing_address1`, `billing_address2`, `billing_city`, `billing_state`, `billing_state_code`, `billing_pincode`, `billing_fax`, `billing_phone`, `shipping_recipient_name`, `shipping_country`, `shipping_address1`, `shipping_address2`, `shipping_city`, `shipping_state`, `shipping_state_code`, `shipping_pincode`, `remark`, `created_at`, `status`) VALUES
(1, 'Domestic', 'MR', 'Rajesh Kumar', 'Kumar Industries', 'Rajesh Kumar', 'rajesh.kumar@kumarind.com', '9876543210', '02212345678', 'ABCDE1234F', '27AAAAA0000A1Z5', 'INR', NULL, 'Rajesh Kumar', 'India', '123 Billing Street', 'Suite 456', 'Mumbai', 'Maharashtra', '27', '400001', NULL, NULL, NULL, 'India', '123 Shipping Lane', NULL, 'Mumbai', 'Maharashtra', '27', '400001', NULL, NOW(), 'Active'),
(2, 'Domestic', 'MS', 'Sonal Sharma', 'Sharma Solutions', 'Sonal Sharma', 'sonal.sharma@sharmasol.com', '9123456789', '02298765432', 'ABCDE5678G', '27BBBBB1111B2Z6', 'INR', NULL, 'Sonal Sharma', 'India', '45 Billing Ave', NULL, 'Pune', 'Maharashtra', '27', '411001', NULL, NULL, NULL, 'India', '78 Shipping Rd', NULL, 'Pune', 'Maharashtra', '27', '411001', NULL, NOW(), 'Active'),
(3, 'International', 'DR', 'Dr. Rahul Mehra', 'Mehra Healthcare', 'Dr. Rahul Mehra', 'rahul.mehra@health.com', '9988776655', '08022334455', 'AABCD2345H', '29CCCCCC2222C3Z7', 'INR', NULL, 'Dr. Rahul Mehra', 'India', '789 Health Road', 'Block B', 'Bangalore', 'Karnataka', '29', '560001', NULL, NULL, NULL, 'India', '123 Care Avenue', NULL, 'Bangalore', 'Karnataka', '29', '560001', NULL, NOW(), 'Active'),
(4, 'Domestic', 'MR', 'Anil Patel', 'Patel Fabrics', 'Anil Patel', 'anil.patel@patelfab.com', '9123456780', '02211112222', 'ABCDE8765J', '27DDDDD3333D4Z8', 'INR', NULL, 'Anil Patel', 'India', '12 Fabric Lane', NULL, 'Nagpur', 'Maharashtra', '27', '440001', NULL, NULL, NULL, 'India', '34 Shipping Blvd', NULL, 'Nagpur', 'Maharashtra', '27', '440001', NULL, NOW(), 'Active'),
(5, 'International', 'MS', 'Alice Smith', 'Smith Global Ltd', 'A. Smith', 'alice.smith@example.com', '1234567890', '01123456789', 'ABCDE5678K', '29EEE1111E5Z9', 'USD', NULL, 'Bob Smith', 'USA', '456 Elm Street', 'Apt 12', 'New York', 'NY', '34', '10001', NULL, NULL, NULL, 'USA', '789 Oak Avenue', NULL, 'Los Angeles', 'CA', '06', '90001', NULL, NOW(), 'Active'),
(6, 'Domestic', 'MR', 'Vijay Singh', 'Singh Steel', 'Vijay Singh', 'vijay.singh@singhsteel.com', '9876543211', '02233334444', 'ABCDE9999L', '27FFFFF4444F6Z0', 'INR', NULL, 'Vijay Singh', 'India', '56 Steel Road', NULL, 'Aurangabad', 'Maharashtra', '27', '431001', NULL, NULL, NULL, 'India', '78 Shipping St', NULL, 'Aurangabad', 'Maharashtra', '27', '431001', NULL, NOW(), 'Active'),
(7, 'Domestic', 'MS', 'Nisha Gupta', 'Gupta Electronics', 'Nisha Gupta', 'nisha.gupta@guptaelec.com', '9123456799', '02255556666', 'ABCDE1111M', '27GGGGG5555G7Z1', 'INR', NULL, 'Nisha Gupta', 'India', '90 Electronic Park', NULL, 'Nagpur', 'Maharashtra', '27', '440001', NULL, NULL, NULL, 'India', '12 Shipping Lane', NULL, 'Nagpur', 'Maharashtra', '27', '440001', NULL, NOW(), 'Active'),
(8, 'Domestic', 'MR', 'Deepak Verma', 'Verma Constructions', 'Deepak Verma', 'deepak.verma@vermacon.com', '9876543222', '02277778888', 'ABCDE2222N', '27HHHHH6666H8Z2', 'INR', NULL, 'Deepak Verma', 'India', '34 Construction Blvd', NULL, 'Kolhapur', 'Maharashtra', '27', '416001', NULL, NULL, NULL, 'India', '56 Shipping Road', NULL, 'Kolhapur', 'Maharashtra', '27', '416001', NULL, NOW(), 'Active'),
(9, 'International', 'MRS', 'Emily Johnson', 'Johnson Exports', 'E. Johnson', 'emily.johnson@exports.com', '8765432109', '02033445566', 'AACDE6789O', '07IIIII7777I9Z3', 'EUR', NULL, 'Michael Johnson', 'Germany', '321 Export Boulevard', 'Building 9', 'Berlin', 'Berlin', '16', '10115', NULL, NULL, NULL, 'Germany', '654 Import Street', NULL, 'Hamburg', 'Hamburg', '16', '20095', NULL, NOW(), 'Active'),
(10, 'Domestic', 'MR', 'Anusha Rao', 'Rao Textiles', 'Anusha Rao', 'anusha.rao@raotext.com', '9876543299', '02299990000', 'ABCDE3333P', '27IIIII8888J0Z4', 'INR', NULL, 'Anusha Rao', 'India', '78 Textile Lane', NULL, 'Nashik', 'Maharashtra', '27', '422001', NULL, NULL, NULL, 'India', '33 Shipping Ave', NULL, 'Nashik', 'Maharashtra', '27', '422001', NULL, NOW(), 'Active'),
(11, 'Domestic', 'MR', 'Karan Desai', 'Desai Logistics', 'Karan Desai', 'karan.desai@desailog.in', '9811122233', '02211223344', 'BKPPD1234A', '27BKPPD1234A1Z1', 'INR', NULL, 'Karan Desai', 'India', '12 Logistics Park', NULL, 'Thane', 'Maharashtra', '27', '400601', NULL, NULL, NULL, 'India', '12 Logistics Park', NULL, 'Thane', 'Maharashtra', '27', '400601', NULL, NOW(), 'Active'),
(12, 'Domestic', 'MS', 'Priya Kadam', 'Kadam Retail', 'Priya Kadam', 'priya.kadam@kadamretail.com', '9822233344', '02022334455', 'ASDFG5678B', '27ASDFG5678B1Z2', 'INR', NULL, 'Priya Kadam', 'India', 'MG Road', 'Shop 45', 'Pune', 'Maharashtra', '27', '411002', NULL, NULL, NULL, 'India', 'MG Road', 'Shop 45', 'Pune', 'Maharashtra', '27', '411002', NULL, NOW(), 'Active'),
(13, 'International', 'MR', 'David Chen', 'Chen Imports', 'David Chen', 'david.chen@chenimports.sg', '6588889999', '+6567778888', 'ZXCVB9012C', '99ZXCVB9012C1Z3', 'SGD', NULL, 'David Chen', 'Singapore', '10 Bayfront Ave', 'Tower 2', 'Singapore', 'Singapore', '99', '018956', NULL, NULL, NULL, 'Singapore', '10 Bayfront Ave', 'Tower 2', 'Singapore', 'Singapore', '99', '018956', 'VIP Client', NOW(), 'Active'),
(14, 'Domestic', 'MRS', 'Lata Mangesh', 'Mangesh Traders', 'Lata M', 'lata.m@mangeshtraders.in', '9833344455', '02611234567', 'QWERTY3456D', '24QWERTY3456D1Z4', 'INR', NULL, 'Lata Mangesh', 'India', 'Ring Road', 'Plot 10', 'Surat', 'Gujarat', '24', '395001', NULL, NULL, NULL, 'India', 'Ring Road', 'Plot 10', 'Surat', 'Gujarat', '24', '395001', NULL, NOW(), 'Active'),
(15, 'Domestic', 'DR', 'Vikram Batra', 'Batra Pharmaceuticals', 'Dr. Batra', 'info@batrapharma.com', '9844455566', '01123456700', 'MNBVC7890E', '07MNBVC7890E1Z5', 'INR', NULL, 'Vikram Batra', 'India', 'Connaught Place', 'Block C', 'New Delhi', 'Delhi', '07', '110001', NULL, NULL, NULL, 'India', 'Okhla Phase 1', 'Warehouse 5', 'New Delhi', 'Delhi', '07', '110020', NULL, NOW(), 'Active'),
(16, 'International', 'MS', 'Sarah Jenkins', 'Jenkins Ltd', 'S. Jenkins', 'sarah@jenkinsltd.co.uk', '447777888899', '+442071234567', 'LKJHG1234F', '99LKJHG1234F1Z6', 'GBP', NULL, 'Accounts Payable', 'United Kingdom', '15 Oxford St', NULL, 'London', 'London', '99', 'W1D 2CR', NULL, NULL, NULL, 'United Kingdom', '15 Oxford St', NULL, 'London', 'London', '99', 'W1D 2CR', NULL, NOW(), 'Active'),
(17, 'Domestic', 'MR', 'Amit Shah', 'Shah & Sons', 'Amit Shah', 'amit@shahandsons.com', '9855566677', '07923456789', 'POIUY5678G', '24POIUY5678G1Z7', 'INR', NULL, 'Amit Shah', 'India', 'SG Highway', 'Complex 2', 'Ahmedabad', 'Gujarat', '24', '380015', NULL, NULL, NULL, 'India', 'SG Highway', 'Complex 2', 'Ahmedabad', 'Gujarat', '24', '380015', NULL, NOW(), 'Active'),
(18, 'Domestic', 'MS', 'Kavita Reddy', 'Reddy IT Services', 'Kavita Reddy', 'kavita.reddy@reddyit.com', '9866677788', '04033445566', 'VBNMQ9012H', '36VBNMQ9012H1Z8', 'INR', NULL, 'Kavita Reddy', 'India', 'Hitec City', 'Phase 2', 'Hyderabad', 'Telangana', '36', '500081', NULL, NULL, NULL, 'India', 'Hitec City', 'Phase 2', 'Hyderabad', 'Telangana', '36', '500081', NULL, NOW(), 'Active'),
(19, 'Domestic', 'MR', 'Manoj Bajpayee', 'Manoj Productions', 'Manoj B', 'manoj@productions.in', '9877788899', '02266667777', 'ZXCVB3456I', '27ZXCVB3456I1Z9', 'INR', NULL, 'Manoj Bajpayee', 'India', 'Andheri West', 'Studio 4', 'Mumbai', 'Maharashtra', '27', '400053', NULL, NULL, NULL, 'India', 'Andheri West', 'Studio 4', 'Mumbai', 'Maharashtra', '27', '400053', NULL, NOW(), 'Inactive'),
(20, 'International', 'DR', 'Hans Muller', 'Muller Tech', 'Dr. Muller', 'hans.muller@mullertech.de', '491512345678', '+4989123456', 'QWERT7890J', '99QWERT7890J1Z0', 'EUR', NULL, 'Hans Muller', 'Germany', 'Munich Tech Park', 'Bldg A', 'Munich', 'Bavaria', '99', '80331', NULL, NULL, NULL, 'Germany', 'Munich Tech Park', 'Bldg A', 'Munich', 'Bavaria', '99', '80331', NULL, NOW(), 'Active'),
(21, 'Domestic', 'MRS', 'Sneha Kapoor', 'Kapoor Fashions', 'Sneha Kapoor', 'sneha@kapoorfashions.com', '9888899900', '01144445555', 'ASDFG1234K', '07ASDFG1234K1Z1', 'INR', NULL, 'Sneha Kapoor', 'India', 'Lajpat Nagar', 'Market Area', 'New Delhi', 'Delhi', '07', '110024', NULL, NULL, NULL, 'India', 'Lajpat Nagar', 'Market Area', 'New Delhi', 'Delhi', '07', '110024', NULL, NOW(), 'Active'),
(22, 'Domestic', 'MR', 'Rohan Das', 'Das Enterprise', 'Rohan Das', 'rohan.das@dasent.com', '9899900011', '03322223333', 'ZXCVB5678L', '19ZXCVB5678L1Z2', 'INR', NULL, 'Rohan Das', 'India', 'Park Street', 'Floor 5', 'Kolkata', 'West Bengal', '19', '700016', NULL, NULL, NULL, 'India', 'Park Street', 'Floor 5', 'Kolkata', 'West Bengal', '19', '700016', NULL, NOW(), 'Active'),
(23, 'International', 'MR', 'Kenji Sato', 'Sato Robotics', 'K. Sato', 'kenji.sato@satorobo.jp', '819012345678', '+81312345678', 'POIUY9012M', '99POIUY9012M1Z3', 'JPY', NULL, 'Kenji Sato', 'Japan', 'Akihabara', 'Robotics Tower', 'Tokyo', 'Tokyo', '99', '101-0021', NULL, NULL, NULL, 'Japan', 'Akihabara', 'Robotics Tower', 'Tokyo', 'Tokyo', '99', '101-0021', NULL, NOW(), 'Active'),
(24, 'Domestic', 'MS', 'Pooja Iyer', 'Iyer Consulting', 'Pooja Iyer', 'pooja@iyerconsulting.in', '9900011122', '04455556666', 'MNBVC3456N', '33MNBVC3456N1Z4', 'INR', NULL, 'Pooja Iyer', 'India', 'T Nagar', 'Main Road', 'Chennai', 'Tamil Nadu', '33', '600017', NULL, NULL, NULL, 'India', 'T Nagar', 'Main Road', 'Chennai', 'Tamil Nadu', '33', '600017', NULL, NOW(), 'Active'),
(25, 'Domestic', 'MR', 'Gaurav Tiwari', 'Tiwari Motors', 'Gaurav Tiwari', 'gaurav.tiwari@motors.com', '9911122233', '07312223344', 'LKJHG7890O', '23LKJHG7890O1Z5', 'INR', NULL, 'Gaurav Tiwari', 'India', 'AB Road', 'Motor Market', 'Indore', 'Madhya Pradesh', '23', '452001', NULL, NULL, NULL, 'India', 'Sanwer Road', 'Industrial Area', 'Indore', 'Madhya Pradesh', '23', '452015', NULL, NOW(), 'Active'),
(26, 'International', 'MRS', 'Laura Rossi', 'Rossi Designs', 'Laura Rossi', 'laura.rossi@designs.it', '393331234567', '+39021234567', 'QWERTY1234P', '99QWERTY1234P1Z6', 'EUR', NULL, 'Laura Rossi', 'Italy', 'Via Roma 10', NULL, 'Milan', 'Lombardy', '99', '20121', NULL, NULL, NULL, 'Italy', 'Via Roma 10', NULL, 'Milan', 'Lombardy', '99', '20121', NULL, NOW(), 'Active'),
(27, 'Domestic', 'MR', 'Tariq Khan', 'Khan Travels', 'Tariq Khan', 'tariq.khan@khantravels.com', '9922233344', '05223344556', 'ASDFG5678Q', '09ASDFG5678Q1Z7', 'INR', NULL, 'Tariq Khan', 'India', 'Hazratganj', 'Shop 12', 'Lucknow', 'Uttar Pradesh', '09', '226001', NULL, NULL, NULL, 'India', 'Hazratganj', 'Shop 12', 'Lucknow', 'Uttar Pradesh', '09', '226001', NULL, NOW(), 'Inactive'),
(28, 'Domestic', 'DR', 'Neha Joshi', 'Joshi Clinics', 'Dr. Joshi', 'dr.neha@joshiclinics.in', '9933344455', '01415556666', 'ZXCVB9012R', '08ZXCVB9012R1Z8', 'INR', NULL, 'Neha Joshi', 'India', 'Malviya Nagar', 'Sector 4', 'Jaipur', 'Rajasthan', '08', '302017', NULL, NULL, NULL, 'India', 'Malviya Nagar', 'Sector 4', 'Jaipur', 'Rajasthan', '08', '302017', NULL, NOW(), 'Active'),
(29, 'International', 'MR', 'Omar Al-Fayed', 'Al-Fayed Trade', 'Omar Al-Fayed', 'omar@alfayedtrade.ae', '971501234567', '+97141234567', 'POIUY3456S', '99POIUY3456S1Z9', 'AED', NULL, 'Omar Al-Fayed', 'UAE', 'Sheikh Zayed Rd', 'Trade Centre', 'Dubai', 'Dubai', '99', '00000', NULL, NULL, NULL, 'UAE', 'Jebel Ali', 'Freezone', 'Dubai', 'Dubai', '99', '00000', 'Wholesale Buyer', NOW(), 'Active'),
(30, 'Domestic', 'MS', 'Ritu Phogat', 'Phogat Sports', 'Ritu P', 'ritu.phogat@sports.com', '9944455566', '01726667777', 'MNBVC7890T', '03MNBVC7890T1Z0', 'INR', NULL, 'Ritu Phogat', 'India', 'Sector 17', 'Plaza Area', 'Chandigarh', 'Chandigarh', '03', '160017', NULL, NULL, NULL, 'India', 'Sector 17', 'Plaza Area', 'Chandigarh', 'Chandigarh', '03', '160017', NULL, NOW(), 'Active');

-- --------------------------------------------------------
-- Table structure for table `vendors`
-- --------------------------------------------------------
CREATE TABLE `vendors` (
  `id` int(11) NOT NULL,
  `vendor_name` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `pan` varchar(20) DEFAULT NULL,
  `gst` varchar(20) DEFAULT NULL,
  `billing_recipient_name` varchar(255) DEFAULT NULL,
  `billing_country` varchar(100) DEFAULT NULL,
  `billing_address1` text DEFAULT NULL,
  `billing_address2` text DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_pincode` varchar(20) DEFAULT NULL,
  `billing_fax` varchar(50) DEFAULT NULL,
  `billing_phone` varchar(20) DEFAULT NULL,
  `shipping_recipient_name` varchar(255) DEFAULT NULL,
  `shipping_country` varchar(100) DEFAULT NULL,
  `shipping_address1` text DEFAULT NULL,
  `shipping_address2` text DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_pincode` varchar(20) DEFAULT NULL,
  `shipping_fax` varchar(50) DEFAULT NULL,
  `shipping_phone` varchar(20) DEFAULT NULL,
  `account_holder_name` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `ifsc` varchar(20) DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `vendors` (`id`, `vendor_name`, `company_name`, `display_name`, `email`, `phone`, `pan`, `gst`, `billing_recipient_name`, `billing_country`, `billing_address1`, `billing_address2`, `billing_city`, `billing_state`, `billing_pincode`, `billing_fax`, `billing_phone`, `shipping_recipient_name`, `shipping_country`, `shipping_address1`, `shipping_address2`, `shipping_city`, `shipping_state`, `shipping_pincode`, `shipping_fax`, `shipping_phone`, `account_holder_name`, `bank_name`, `account_number`, `ifsc`, `remark`, `status`) VALUES
(1, 'Anush Raju', 'BD College Wardha', 'Anush Raju', 'anshupise95@gmail.com', '07588674622', 'ABCDE1234F', '27AAAAA0000A1Z5', 'Anush Raju', 'India', 'KOCHER WARD HINGANGHAT', 'LIC OFFICE ROAD', 'Wardha', 'Maharashtra', '442001', NULL, NULL, 'Anush Raju', 'India', 'KOCHER WARD HINGANGHAT', 'LIC OFFICE ROAD', 'Wardha', 'Maharashtra', '442001', NULL, NULL, 'Anush Raju', 'State Bank of India', '1234567890', 'SBIN0001234', NULL, 'Active'),
(2, 'Raju Ramesh Pise', 'Tech Galaxy Grow', 'Raju Ramesh', 'rajupise001@gmail.com', '07823084754', 'ABCDE5678Q', '29BBBBB1111B2Z6', 'Raju Ramesh', 'India', 'Wardha', 'LIC OFFICE ROAD', 'Wardha', 'Maharashtra', '442001', NULL, NULL, 'Raju Ramesh', 'India', 'Wardha', 'LIC OFFICE ROAD', 'Wardha', 'Maharashtra', '442001', NULL, NULL, 'Raju Ramesh', 'HDFC Bank', '9876543210', 'HDFC0005678', NULL, 'Active'),
(3, 'Kasturi Enterprises', 'Kasturi Enterprises', 'Kasturi', 'kasturi@enterprise.com', '07823084755', 'ABCDE9999R', '27CCCCCC2222C3Z7', 'Kasturi', 'India', 'Kochi', 'Industrial Area', 'Kochi', 'Kerala', '682001', NULL, NULL, 'Kasturi', 'India', 'Kochi', 'Industrial Area', 'Kochi', 'Kerala', '682001', NULL, NULL, 'Kasturi', 'ICICI Bank', '1122334455', 'ICIC0001122', NULL, 'Active'),
(4, 'Anush Pise', 'Anush Manufacturing', 'Anush Pise', 'anushpise@example.com', '07588674623', 'ABCDE5555S', '27DDDDD3333D4Z8', 'Anush Pise', 'India', 'Pune', 'Industrial Park', 'Pune', 'Maharashtra', '411001', NULL, NULL, 'Anush Pise', 'India', 'Pune', 'Industrial Park', 'Pune', 'Maharashtra', '411001', NULL, NULL, 'Anush Pise', 'Axis Bank', '2233445566', 'UTIB0003344', NULL, 'Active'),
(5, 'Akshay Wadi', 'Cosmos Digital', 'Akshay', 'akshay.wadi@cosmosdigital.com', '07823084756', 'ABCDE7777T', '27EEEEEE4444E5Z9', 'Akshay Wadi', 'India', 'Wardha', 'LIC Office Road', 'Wardha', 'Maharashtra', '442001', NULL, NULL, 'Akshay Wadi', 'India', 'Wardha', 'LIC Office Road', 'Wardha', 'Maharashtra', '442001', NULL, NULL, 'Akshay Wadi', 'Punjab National Bank', '3344556677', 'PUNB0005555', NULL, 'Active'),
(6, 'Starte Bap', 'Starte Bap Corp', 'Starte', 'startebap@example.com', '07588674624', 'ABCDE8888U', '27FFFFF5555F6Z0', 'Starte Bap', 'India', 'Wardha', 'LIC Office Road', 'Wardha', 'Maharashtra', '442001', NULL, NULL, 'Starte Bap', 'India', 'Wardha', 'LIC Office Road', 'Wardha', 'Maharashtra', '442001', NULL, NULL, 'Starte Bap', 'Bank of Baroda', '4455667788', 'BARB0006666', NULL, 'Active'),
(7, 'Kasturi', 'Kasturi Enterprises', 'Kasturi', 'kasturi@enterprise.com', '07823084757', 'ABCDE9999V', '27GGGGG6666G7Z1', 'Kasturi', 'India', 'Kochi', 'Industrial Area', 'Kochi', 'Kerala', '682001', NULL, NULL, 'Kasturi', 'India', 'Kochi', 'Industrial Area', 'Kochi', 'Kerala', '682001', NULL, NULL, 'Kasturi', 'Yes Bank', '5566778899', 'YESB0007777', NULL, 'Active'),
(8, 'Mohan Lal', 'Lal Traders', 'Mohan Lal', 'mohan.lal@traders.in', '9876543210', 'BXCDE1234G', '07BXCDE1234G1Z1', 'Mohan Lal', 'India', 'Chandni Chowk', 'Shop 45', 'New Delhi', 'Delhi', '110006', NULL, NULL, 'Mohan Lal', 'India', 'Chandni Chowk', 'Shop 45', 'New Delhi', 'Delhi', '110006', NULL, NULL, 'Mohan Lal Traders', 'HDFC Bank', '501002345678', 'HDFC0000123', NULL, 'Active'),
(9, 'Sunita Sharma', 'Sharma Solutions', 'Sunita', 'sunita@sharmasol.com', '9988776655', 'ASDFG5678H', '33ASDFG5678H1Z2', 'Sunita Sharma', 'India', 'T Nagar', NULL, 'Chennai', 'Tamil Nadu', '600017', NULL, NULL, 'Sunita Sharma', 'India', 'T Nagar', NULL, 'Chennai', 'Tamil Nadu', '600017', NULL, NULL, 'Sharma Solutions', 'State Bank of India', '30201040506', 'SBIN0000456', NULL, 'Active'),
(10, 'Rajiv Mehta', 'Mehta Logistics', 'Rajiv Mehta', 'info@mehtalogistics.com', '9898989898', 'QWERT9012I', '24QWERT9012I1Z3', 'Rajiv Mehta', 'India', 'SG Highway', 'Tower B', 'Ahmedabad', 'Gujarat', '380015', NULL, NULL, 'Rajiv Mehta', 'India', 'SG Highway', 'Tower B', 'Ahmedabad', 'Gujarat', '380015', NULL, NULL, 'Mehta Logistics', 'ICICI Bank', '000105001234', 'ICIC0000001', NULL, 'Active'),
(11, 'Anita Desai', 'Desai Exports', 'Anita', 'anita.desai@exports.in', '8877665544', 'ZXCVB3456J', '27ZXCVB3456J1Z4', 'Anita Desai', 'India', 'Andheri West', 'MIDC', 'Mumbai', 'Maharashtra', '400053', NULL, NULL, 'Anita Desai', 'India', 'Andheri West', 'MIDC', 'Mumbai', 'Maharashtra', '400053', NULL, NULL, 'Desai Exports', 'Axis Bank', '910010023456789', 'UTIB0000002', NULL, 'Inactive'),
(12, 'Kiran Rao', 'Rao Electronics', 'Kiran Rao', 'kiran@raoelectronics.com', '7766554433', 'PLMKO7890K', '29PLMKO7890K1Z5', 'Kiran Rao', 'India', 'Electronic City', 'Phase 1', 'Bangalore', 'Karnataka', '560100', NULL, NULL, 'Kiran Rao', 'India', 'Electronic City', 'Phase 1', 'Bangalore', 'Karnataka', '560100', NULL, NULL, 'Rao Electronics', 'Kotak Mahindra', '1234509876', 'KKBK0000456', NULL, 'Active'),
(13, 'Vikram Singh', 'Singh Auto Parts', 'Vikram', 'vikram@singhauto.in', '9900112233', 'MNBVC1234L', '03MNBVC1234L1Z6', 'Vikram Singh', 'India', 'Industrial Area', 'Phase 2', 'Chandigarh', 'Chandigarh', '160002', NULL, NULL, 'Vikram Singh', 'India', 'Industrial Area', 'Phase 2', 'Chandigarh', 'Chandigarh', '160002', NULL, NULL, 'Singh Auto Parts', 'Punjab National Bank', '456700010002', 'PUNB0000123', NULL, 'Active'),
(14, 'Meena Iyer', 'Iyer Consultants', 'Meena Iyer', 'meena@iyerconsult.com', '8899001122', 'POIUY5678M', '33POIUY5678M1Z7', 'Meena Iyer', 'India', 'Adyar', NULL, 'Chennai', 'Tamil Nadu', '600020', NULL, NULL, 'Meena Iyer', 'India', 'Adyar', NULL, 'Chennai', 'Tamil Nadu', '600020', NULL, NULL, 'Iyer Consultants', 'Indian Bank', '7654321098', 'IDIB000A001', NULL, 'Active'),
(15, 'Sanjay Gupta', 'Gupta Hardware', 'Sanjay G', 'sanjay@guptahardware.in', '9988112233', 'LKJHG9012N', '09LKJHG9012N1Z8', 'Sanjay Gupta', 'India', 'Swaroop Nagar', NULL, 'Kanpur', 'Uttar Pradesh', '208002', NULL, NULL, 'Sanjay Gupta', 'India', 'Swaroop Nagar', NULL, 'Kanpur', 'Uttar Pradesh', '208002', NULL, NULL, 'Gupta Hardware', 'Bank of Baroda', '12340200000567', 'BARB0KANPUR', NULL, 'Active'),
(16, 'Pooja Patil', 'Patil Enterprises', 'Pooja Patil', 'pooja@patilent.com', '7788990011', 'JHGFD3456O', '27JHGFD3456O1Z9', 'Pooja Patil', 'India', 'Deccan Gymkhana', NULL, 'Pune', 'Maharashtra', '411004', NULL, NULL, 'Pooja Patil', 'India', 'Deccan Gymkhana', NULL, 'Pune', 'Maharashtra', '411004', NULL, NULL, 'Patil Enterprises', 'Saraswat Bank', '112233445566', 'SRCB0000001', NULL, 'Active'),
(17, 'Ramesh Reddy', 'Reddy IT Services', 'Ramesh R', 'ramesh@reddyit.in', '8877112233', 'VBNMQ7890P', '36VBNMQ7890P1Z0', 'Ramesh Reddy', 'India', 'Hitec City', 'Madhapur', 'Hyderabad', 'Telangana', '500081', NULL, NULL, 'Ramesh Reddy', 'India', 'Hitec City', 'Madhapur', 'Hyderabad', 'Telangana', '500081', NULL, NULL, 'Reddy IT Services', 'Canara Bank', '0987101000123', 'CNRB0000987', NULL, 'Active'),
(18, 'Tariq Khan', 'Khan Travels', 'Tariq', 'tariq@khantravels.com', '9988223344', 'ZXCVB1111Q', '08ZXCVB1111Q1Z1', 'Tariq Khan', 'India', 'MI Road', NULL, 'Jaipur', 'Rajasthan', '302001', NULL, NULL, 'Tariq Khan', 'India', 'MI Road', NULL, 'Jaipur', 'Rajasthan', '302001', NULL, NULL, 'Khan Travels', 'Yes Bank', '000123456789', 'YESB0000002', NULL, 'Inactive'),
(19, 'Deepa Verma', 'Verma Associates', 'Deepa Verma', 'deepa@vermaassoc.in', '7766112233', 'ASDFG2222R', '07ASDFG2222R1Z2', 'Deepa Verma', 'India', 'Connaught Place', 'Block A', 'New Delhi', 'Delhi', '110001', NULL, NULL, 'Deepa Verma', 'India', 'Connaught Place', 'Block A', 'New Delhi', 'Delhi', '110001', NULL, NULL, 'Verma Associates', 'HDFC Bank', '502000123456', 'HDFC0000003', NULL, 'Active'),
(20, 'Manoj Tiwari', 'Tiwari Motors', 'Manoj T', 'manoj@tiwarimotors.com', '9977885566', 'QWERT3333S', '23QWERT3333S1Z3', 'Manoj Tiwari', 'India', 'MP Nagar', 'Zone 1', 'Bhopal', 'Madhya Pradesh', '462011', NULL, NULL, 'Manoj Tiwari', 'India', 'MP Nagar', 'Zone 1', 'Bhopal', 'Madhya Pradesh', '462011', NULL, NULL, 'Tiwari Motors', 'State Bank of India', '30504060708', 'SBIN0000124', NULL, 'Active'),
(21, 'Nitin Bose', 'Bose Engineering', 'Nitin Bose', 'nitin@boseengg.in', '8899776655', 'POIUY4444T', '19POIUY4444T1Z4', 'Nitin Bose', 'India', 'Salt Lake', 'Sector 5', 'Kolkata', 'West Bengal', '700091', NULL, NULL, 'Nitin Bose', 'India', 'Salt Lake', 'Sector 5', 'Kolkata', 'West Bengal', '700091', NULL, NULL, 'Bose Engineering', 'ICICI Bank', '000201005678', 'ICIC0000002', NULL, 'Active'),
(22, 'Geeta Menon', 'Menon Spices', 'Geeta', 'geeta@menonspices.com', '7788556644', 'LKJHG5555U', '32LKJHG5555U1Z5', 'Geeta Menon', 'India', 'MG Road', NULL, 'Ernakulam', 'Kerala', '682016', NULL, NULL, 'Geeta Menon', 'India', 'MG Road', NULL, 'Ernakulam', 'Kerala', '682016', NULL, NULL, 'Menon Spices', 'South Indian Bank', '0123053000012', 'SIBL0000123', NULL, 'Active'),
(23, 'Alok Nath', 'Nath Pharmaceuticals', 'Alok Nath', 'alok@nathpharma.in', '9966554433', 'MNBVC6666V', '27MNBVC6666V1Z6', 'Alok Nath', 'India', 'Sion', 'Chunabhatti', 'Mumbai', 'Maharashtra', '400022', NULL, NULL, 'Alok Nath', 'India', 'Sion', 'Chunabhatti', 'Mumbai', 'Maharashtra', '400022', NULL, NULL, 'Nath Pharmaceuticals', 'Bank of India', '01234567890123', 'BKID0000012', NULL, 'Active'),
(24, 'Radha Krishna', 'RK Jewellers', 'RK Jewellers', 'info@rkjewellers.com', '8855443322', 'ZXCVB7777W', '29ZXCVB7777W1Z7', 'Radha Krishna', 'India', 'Jayanagar', '4th Block', 'Bangalore', 'Karnataka', '560011', NULL, NULL, 'Radha Krishna', 'India', 'Jayanagar', '4th Block', 'Bangalore', 'Karnataka', '560011', NULL, NULL, 'RK Jewellers', 'Axis Bank', '920010034567890', 'UTIB0000003', NULL, 'Active'),
(25, 'Imran Shaikh', 'Shaikh Builders', 'Imran S', 'imran@shaikhbuilders.in', '7744332211', 'ASDFG8888X', '27ASDFG8888X1Z8', 'Imran Shaikh', 'India', 'Vashi', 'Sector 17', 'Navi Mumbai', 'Maharashtra', '400703', NULL, NULL, 'Imran Shaikh', 'India', 'Vashi', 'Sector 17', 'Navi Mumbai', 'Maharashtra', '400703', NULL, NULL, 'Shaikh Builders', 'HDFC Bank', '501000987654', 'HDFC0000004', NULL, 'Active'),
(26, 'Kavita Das', 'Das Fabrics', 'Kavita Das', 'kavita@dasfabrics.com', '9933221100', 'QWERT9999Y', '24QWERT9999Y1Z9', 'Kavita Das', 'India', 'Ring Road', NULL, 'Surat', 'Gujarat', '395002', NULL, NULL, 'Kavita Das', 'India', 'Ring Road', NULL, 'Surat', 'Gujarat', '395002', NULL, NULL, 'Das Fabrics', 'State Bank of India', '30807060504', 'SBIN0000125', NULL, 'Inactive'),
(27, 'Ravi Teja', 'Teja Studios', 'Ravi Teja', 'ravi@tejastudios.in', '8822110099', 'PLMKO1111Z', '36PLMKO1111Z1Z0', 'Ravi Teja', 'India', 'Banjara Hills', 'Road No 12', 'Hyderabad', 'Telangana', '500034', NULL, NULL, 'Ravi Teja', 'India', 'Banjara Hills', 'Road No 12', 'Hyderabad', 'Telangana', '500034', NULL, NULL, 'Teja Studios', 'Kotak Mahindra', '9876501234', 'KKBK0000457', 'VIP Vendor', 'Active');

-- --------------------------------------------------------
-- Table structure for table `products_services`
-- --------------------------------------------------------
CREATE TABLE `products_services` (
  `id` int(11) NOT NULL,
  `type` enum('Product','Service') NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `tax_applicable` varchar(100) DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `category` varchar(100) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `sale_discount` decimal(5,2) DEFAULT NULL,
  `sale_discount_type` enum('%','Flat') DEFAULT '%',
  `sale_description` text DEFAULT NULL,
  `purchase_price` decimal(10,2) DEFAULT NULL,
  `purchase_discount` decimal(5,2) DEFAULT NULL,
  `purchase_discount_type` enum('%','Flat') DEFAULT '%',
  `purchase_description` text DEFAULT NULL,
  `preferred_vendor` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `products_services` (`id`, `type`, `product_name`, `sku`, `tax_applicable`, `status`, `category`, `unit`, `sale_price`, `sale_discount`, `sale_discount_type`, `sale_description`, `purchase_price`, `purchase_discount`, `purchase_discount_type`, `purchase_description`, `preferred_vendor`, `created_at`) VALUES
(1, 'Product', 'Industrial Bolt', 'IB-001', 'CGST,SGST', 'Active', 'Fasteners', 'pcs', 120.00, 5.00, '%', 'High strength bolt', 80.00, 0.00, '%', NULL, 'Anush Raju', NOW()),
(2, 'Product', 'Steel Plate', 'SP-010', 'CGST,SGST', 'Active', 'Raw Material', 'kg', 500.00, 10.00, '%', 'Grade A steel plate', 350.00, 0.00, '%', NULL, 'Raju Ramesh Pise', NOW()),
(3, 'Product', 'Hydraulic Pump', 'HP-200', 'IGST', 'Active', 'Machinery', 'pcs', 2500.00, 5.00, '%', 'Industrial hydraulic pump', 1800.00, 0.00, '%', NULL, 'Kasturi Enterprises', NOW()),
(4, 'Service', 'Installation Service', NULL, 'CGST,SGST', 'Active', 'Service', NULL, 1500.00, 0.00, '%', 'Installation of equipment', NULL, NULL, '%', NULL, NULL, NOW()),
(5, 'Product', 'Electrical Cable', 'EC-100', 'CGST,SGST', 'Active', 'Electrical', 'm', 20.00, 0.00, '%', NULL, 12.00, 0.00, '%', NULL, 'Akshay Wadi', NOW()),
(6, 'Product', 'Aluminium Sheet', 'AS-050', 'CGST,SGST', 'Active', 'Raw Material', 'kg', 300.00, 0.00, '%', NULL, 200.00, 0.00, '%', NULL, 'Starte Bap', NOW()),
(7, 'Service', 'Consultancy', NULL, 'IGST', 'Active', 'Service', NULL, 5000.00, 0.00, '%', 'Business consultancy', NULL, NULL, '%', NULL, 'Kasturi', NOW()),
(8, 'Product', 'Plastic Granules', 'PG-500', 'CGST,SGST', 'Inactive', 'Raw Material', 'kg', 150.00, 0.00, '%', NULL, 100.00, 0.00, '%', NULL, NULL, NOW()),
(9, 'Product', 'Titanium Drill Bit', 'DB-T01', 'CGST,SGST', 'Active', 'Tools', 'pcs', 450.00, 10.00, '%', 'High durability drill bit', 250.00, 5.00, '%', 'Bulk drill bits', 'Anush Raju', NOW()),
(10, 'Service', 'Annual Maintenance', NULL, 'IGST', 'Active', 'Maintenance', 'years', 12000.00, 999.00, 'Flat', 'Annual machinery maintenance contract', NULL, NULL, '%', NULL, NULL, NOW()),
(11, 'Product', 'PVC Pipe 2 inch', 'PVC-20', 'CGST,SGST', 'Active', 'Plumbing', 'm', 85.00, 0.00, '%', 'Standard PVC pipe', 55.00, 0.00, '%', NULL, 'Akshay Wadi', NOW()),
(12, 'Product', 'Copper Wire Roll', 'CW-500', 'IGST', 'Active', 'Electrical', 'kg', 1200.00, 5.00, '%', 'Bare copper wire 2mm thickness', 900.00, 2.00, '%', NULL, 'Starte Bap', NOW()),
(13, 'Service', 'Cloud Hosting Setup', NULL, 'CGST,SGST', 'Active', 'IT Services', 'hours', 3000.00, 0.00, '%', 'Initial server configuration and deployment', NULL, NULL, '%', NULL, NULL, NOW()),
(14, 'Product', 'Safety Helmets', 'SH-YEL', 'CGST,SGST', 'Active', 'Safety Gear', 'pcs', 350.00, 50.00, 'Flat', 'Yellow hard hat for construction', 180.00, 0.00, '%', NULL, 'Raju Ramesh Pise', NOW()),
(15, 'Product', 'Industrial Lubricant', 'LUB-20L', 'IGST', 'Active', 'Consumables', 'liters', 400.00, 5.00, '%', '20L drum of machinery lubricant', 280.00, 0.00, '%', NULL, 'Kasturi Enterprises', NOW()),
(16, 'Product', 'LED Panel Light', 'LED-P30', 'CGST,SGST', 'Inactive', 'Electrical', 'pcs', 1800.00, 10.00, '%', '30W square ceiling panel', 1200.00, 5.00, '%', 'Old stock clearance', 'Akshay Wadi', NOW()),
(17, 'Service', 'Software Audit', NULL, 'IGST', 'Active', 'Consulting', 'hours', 8000.00, 0.00, '%', 'Security and compliance software audit', NULL, NULL, '%', NULL, 'Kasturi', NOW()),
(18, 'Product', 'Stainless Steel Screws', 'SSS-100', 'CGST,SGST', 'Active', 'Fasteners', 'box', 250.00, 0.00, '%', 'Pack of 100 1-inch screws', 150.00, 0.00, '%', NULL, 'Anush Raju', NOW()),
(19, 'Product', 'Concrete Mix', 'CMX-50', 'CGST,SGST', 'Active', 'Raw Material', 'bags', 450.00, 2.00, '%', '50kg ready mix bag', 320.00, 0.00, '%', NULL, 'Raju Ramesh Pise', NOW()),
(20, 'Product', 'Heavy Duty Bearings', 'BRG-X9', 'IGST', 'Active', 'Machinery', 'pcs', 3200.00, 15.00, '%', 'Industrial roller bearing assembly', 2400.00, 5.00, '%', NULL, 'Kasturi Enterprises', NOW()),
(21, 'Service', 'Machinery Transport', NULL, 'CGST,SGST', 'Active', 'Logistics', 'km', 50.00, 0.00, '%', 'Heavy goods transport rate per km', NULL, NULL, '%', NULL, NULL, NOW()),
(22, 'Product', 'Rubber Gaskets', 'RG-05', 'CGST,SGST', 'Active', 'Spare Parts', 'pcs', 45.00, 0.00, '%', '5mm high-pressure rubber seal', 25.00, 0.00, '%', NULL, 'Starte Bap', NOW()),
(23, 'Product', 'Fiberglass Insulation', 'FGI-Roll', 'IGST', 'Active', 'Building Material', 'm', 150.00, 5.00, '%', 'Thermal insulation roll for walls', 90.00, 0.00, '%', NULL, 'Anush Raju', NOW()),
(24, 'Service', 'Graphic Design', NULL, 'IGST', 'Active', 'Marketing', 'project', 15000.00, 10.00, '%', 'Corporate branding and logo design package', NULL, NULL, '%', NULL, NULL, NOW()),
(25, 'Product', 'Welding Rods', 'WR-316', 'CGST,SGST', 'Active', 'Consumables', 'kg', 220.00, 0.00, '%', 'Stainless steel welding rods', 160.00, 0.00, '%', NULL, 'Raju Ramesh Pise', NOW()),
(26, 'Product', 'Office Chair', 'OC-ERG', 'CGST,SGST', 'Inactive', 'Furniture', 'pcs', 4500.00, 500.00, 'Flat', 'Ergonomic mesh chair with lumbar support', 2800.00, 0.00, '%', 'Discontinued model', 'Akshay Wadi', NOW()),
(27, 'Service', 'On-site Troubleshooting', NULL, 'CGST,SGST', 'Active', 'Maintenance', 'hours', 2500.00, 0.00, '%', 'Emergency repair call-out service', NULL, NULL, '%', NULL, NULL, NOW()),
(28, 'Product', 'Generator 5kVA', 'GEN-5K', 'IGST', 'Active', 'Machinery', 'pcs', 45000.00, 5.00, '%', 'Portable diesel backup generator', 35000.00, 2.00, '%', NULL, 'Kasturi Enterprises', NOW());

-- --------------------------------------------------------
-- Table structure for table `taxes`
-- --------------------------------------------------------
CREATE TABLE `taxes` (
  `id` int(11) NOT NULL,
  `tax_name` varchar(100) DEFAULT NULL,
  `tax_rate` decimal(5,2) DEFAULT NULL,
  `tax_code` varchar(50) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `effective_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `taxes` (`id`, `tax_name`, `tax_rate`, `tax_code`, `details`, `status`, `effective_date`) VALUES
(1, 'CGST', 9.00, 'CGST-9', 'Central GST', 'Active', '2025-04-01'),
(2, 'SGST', 9.00, 'SGST-9', 'State GST', 'Active', '2025-04-01'),
(3, 'IGST', 18.00, 'IGST-18', 'Integrated GST for inter‑state', 'Active', '2025-04-01'),
(4, 'GST Cess', 1.00, 'GSTC-1', 'Cess applicable on certain goods', 'Active', '2025-04-01'),
(5, 'Service Tax', 15.00, 'ST-15', 'Service tax for non‑GST services', 'Active', '2025-04-01'),
(6, 'CGST', 2.50, 'CGST-2.5', 'Central GST @ 2.5%', 'Active', '2025-04-01'),
(7, 'SGST', 2.50, 'SGST-2.5', 'State GST @ 2.5%', 'Active', '2025-04-01'),
(8, 'IGST', 5.00, 'IGST-5', 'Integrated GST @ 5%', 'Active', '2025-04-01'),
(9, 'CGST', 6.00, 'CGST-6', 'Central GST @ 6%', 'Active', '2025-04-01'),
(10, 'SGST', 6.00, 'SGST-6', 'State GST @ 6%', 'Active', '2025-04-01'),
(11, 'IGST', 12.00, 'IGST-12', 'Integrated GST @ 12%', 'Active', '2025-04-01'),
(12, 'CGST', 14.00, 'CGST-14', 'Central GST @ 14%', 'Active', '2025-04-01'),
(13, 'SGST', 14.00, 'SGST-14', 'State GST @ 14%', 'Active', '2025-04-01'),
(14, 'IGST', 28.00, 'IGST-28', 'Integrated GST @ 28%', 'Active', '2025-04-01'),
(15, 'IGST (Zero Rated)', 0.00, 'IGST-0', 'Zero Rated IGST for Exports/SEZ', 'Active', '2025-04-01'),
(16, 'GST Cess (Auto)', 22.00, 'GSTC-22', 'Compensation cess for large vehicles', 'Active', '2025-04-01'),
(17, 'TDS (Rent)', 10.00, 'TDS-194I', 'TDS on Rent of Land/Building', 'Active', '2025-04-01'),
(18, 'TDS (Professional)', 10.00, 'TDS-194J', 'TDS on Professional/Technical Fees', 'Active', '2025-04-01'),
(19, 'TDS (Contractor-Ind)', 1.00, 'TDS-194C-1', 'TDS for Individual/HUF Contractors', 'Active', '2025-04-01'),
(20, 'TDS (Contractor-Co)', 2.00, 'TDS-194C-2', 'TDS for Company Contractors', 'Active', '2025-04-01'),
(21, 'TCS (Goods)', 0.10, 'TCS-206C', 'TCS on sale of specific goods > 50L', 'Active', '2025-04-01'),
(22, 'VAT', 5.00, 'VAT-5', 'Value Added Tax (Non-GST items)', 'Active', '2025-04-01'),
(23, 'VAT', 14.50, 'VAT-14.5', 'Value Added Tax standard rate', 'Inactive', '2024-04-01'),
(24, 'Professional Tax', 0.00, 'PT-SLAB', 'Professional Tax (Slab based deductor)', 'Active', '2025-04-01'),
(25, 'Luxury Tax', 12.00, 'LUX-12', 'Legacy luxury tax rate', 'Inactive', '2023-04-01');

-- --------------------------------------------------------
-- Table structure for table `financial_years`
-- --------------------------------------------------------
CREATE TABLE `financial_years` (
  `id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `financial_years` (`id`, `start_date`, `end_date`, `is_active`, `created_at`) VALUES
(1, '2023-04-01', '2024-03-31', 0, NOW()),
(2, '2024-04-01', '2025-03-31', 0, NOW()),
(3, '2025-04-01', '2026-06-30', 1, NOW());

-- --------------------------------------------------------
-- Table structure for table `invoice`
-- --------------------------------------------------------
CREATE TABLE `invoice` (
  `invoice_number` varchar(20) DEFAULT NULL,
  `customer_name` varchar(255) NOT NULL,
  `invoice_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `customer_notes` text DEFAULT NULL,
  `terms_and_conditions` text DEFAULT NULL,
  `sub_total` double DEFAULT NULL,
  `freight` decimal(10,2) DEFAULT 0.00,
  `cgst` double DEFAULT NULL,
  `sgst` double DEFAULT NULL,
  `igst` decimal(10,2) DEFAULT 0.00,
  `grand_total` double DEFAULT NULL,
  `status` enum('Draft','Partial','Paid') DEFAULT 'Draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `financial_year_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `invoice` (`invoice_number`, `customer_name`, `invoice_date`, `expiry_date`, `subject`, `customer_notes`, `terms_and_conditions`, `sub_total`, `freight`, `cgst`, `sgst`, `igst`, `grand_total`, `status`, `created_at`, `customer_id`, `invoice_id`, `financial_year_id`) VALUES
('ME/2025-26/001', 'Rajesh Kumar', '2026-04-01', '2026-04-15', 'Supply of industrial bolts', 'Please deliver by 15th Aug', 'Net 30', 1200.00, 0.00, 108.00, 108.00, 0.00, 1416.00, 'Draft', NOW(), 1, 1, 3),
('ME/2025-26/002', 'Sonal Sharma', '2026-04-05', '2026-04-20', 'Steel plates order', 'Urgent delivery', 'Net 15', 5000.00, 0.00, 450.00, 450.00, 0.00, 5900.00, 'Draft', NOW(), 2, 2, 3),
('ME/2025-26/003', 'Dr. Rahul Mehra', '2026-04-07', '2026-04-22', 'Hydraulic pump supply', '', 'Net 45', 2500.00, 0.00, 0.00, 0.00, 450.00, 2950.00, 'Draft', NOW(), 3, 3, 3),
('ME/2025-26/004', 'Anil Patel', '2026-04-10', '2026-04-25', 'Electrical cables batch', '', 'Net 30', 2000.00, 0.00, 180.00, 180.00, 0.00, 2360.00, 'Draft', NOW(), 4, 4, 3),
('ME/2025-26/005', 'Vijay Singh', '2026-04-12', '2026-04-27', 'Aluminium sheets', '', 'Net 30', 3000.00, 0.00, 270.00, 270.00, 0.00, 3540.00, 'Draft', NOW(), 5, 5, 3),
('ME/2025-26/006', 'Nisha Gupta', '2026-04-14', '2026-04-29', 'Installation service', '', 'Net 60', 1500.00, 0.00, 135.00, 135.00, 0.00, 1770.00, 'Draft', NOW(), 6, 6, 3),
('ME/2025-26/007', 'Deepak Verma', '2026-04-16', '2026-04-31', 'Plastic granules', '', 'Net 30', 1500.00, 0.00, 135.00, 135.00, 0.00, 1770.00, 'Draft', NOW(), 7, 7, 3),
('ME/2025-26/008', 'Emily Johnson', '2026-04-18', '2026-05-02', 'Consultancy service', '', 'Net 45', 5000.00, 0.00, 750.00, 750.00, 0.00, 6500.00, 'Draft', NOW(), 8, 8, 3),
('ME/2025-26/009', 'Anusha Rao', '2026-04-20', '2026-05-04', 'Textile order', '', 'Net 30', 2500.00, 0.00, 225.00, 225.00, 0.00, 2950.00, 'Draft', NOW(), 9, 9, 3),
('ME/2025-26/010', 'Alice Smith', '2026-04-22', '2026-05-06', 'Consultancy for US client', '', 'Net 30', 3000.00, 0.00, 0.00, 0.00, 540.00, 3540.00, 'Draft', NOW(), 10, 10, 3),
('ME/2025-26/011', 'Karan Desai', '2026-04-25', '2026-05-09', 'Logistics equipment', 'Deliver to Thane warehouse', 'Net 15', 8000.00, 0.00, 720.00, 720.00, 0.00, 9440.00, 'Draft', NOW(), 11, 11, 3),
('ME/2025-26/012', 'Priya Kadam', '2026-04-26', '2026-05-25', 'Retail shelving units', '', 'Net 30', 4500.00, 500.00, 450.00, 450.00, 0.00, 5900.00, 'Paid', NOW(), 12, 12, 3),
('ME/2025-26/013', 'David Chen', '2026-04-27', '2026-05-11', 'Imported machinery parts', 'Export packaging required', 'Net 15', 12000.00, 0.00, 0.00, 0.00, 2160.00, 14160.00, 'Partial', NOW(), 13, 13, 3),
('ME/2025-26/014', 'Lata Mangesh', '2026-04-28', '2026-05-27', 'Raw materials bulk', '', 'Net 30', 3200.00, 0.00, 288.00, 288.00, 0.00, 3776.00, 'Draft', NOW(), 14, 14, 3),
('ME/2025-26/015', 'Vikram Batra', '2026-04-29', '2026-05-13', 'Pharmaceutical grade steel', 'Handle with care', 'Net 15', 6700.00, 300.00, 0.00, 0.00, 1260.00, 8260.00, 'Paid', NOW(), 15, 15, 3),
('ME/2025-26/016', 'Sarah Jenkins', '2026-04-30', '2026-05-14', 'Consulting retainer', '', 'Net 15', 21000.00, 0.00, 1890.00, 1890.00, 0.00, 24780.00, 'Draft', NOW(), 16, 16, 3),
('ME/2025-26/017', 'Amit Shah', '2026-05-01', '2026-05-16', 'Spare parts supply', '', 'Net 15', 5400.00, 100.00, 495.00, 495.00, 0.00, 6490.00, 'Paid', NOW(), 17, 17, 3),
('ME/2025-26/018', 'Kavita Reddy', '2026-05-02', '2026-06-02', 'IT hardware procurement', 'Include warranty docs', 'Net 30', 9800.00, 200.00, 0.00, 0.00, 1800.00, 11800.00, 'Partial', NOW(), 18, 18, 3),
('ME/2025-26/019', 'Manoj Bajpayee', '2026-05-03', '2026-05-18', 'Studio lighting equipment', '', 'Net 15', 1500.00, 0.00, 135.00, 135.00, 0.00, 1770.00, 'Paid', NOW(), 19, 19, 3),
('ME/2025-26/020', 'Hans Muller', '2026-05-04', '2026-06-04', 'Technology transfer fee', '', 'Net 30', 8500.00, 0.00, 765.00, 765.00, 0.00, 10030.00, 'Draft', NOW(), 20, 20, 3),
('ME/2025-26/021', 'Sneha Kapoor', '2026-05-05', '2026-05-20', 'Textile machinery maintenance', '', 'Net 15', 11000.00, 0.00, 0.00, 0.00, 1980.00, 12980.00, 'Paid', NOW(), 21, 21, 3),
('ME/2025-26/022', 'Rohan Das', '2026-05-06', '2026-06-06', 'Office furniture', 'Deliver to 5th floor', 'Net 30', 2500.00, 500.00, 270.00, 270.00, 0.00, 3540.00, 'Draft', NOW(), 22, 22, 3),
('ME/2025-26/023', 'Kenji Sato', '2026-05-07', '2026-05-22', 'Robotics components', '', 'Net 15', 4800.00, 0.00, 432.00, 432.00, 0.00, 5664.00, 'Partial', NOW(), 23, 23, 3),
('ME/2025-26/024', 'Pooja Iyer', '2026-05-08', '2026-06-08', 'Consulting hours - August', '', 'Net 30', 7500.00, 0.00, 0.00, 0.00, 1350.00, 8850.00, 'Paid', NOW(), 24, 24, 3),
('ME/2025-26/025', 'Gaurav Tiwari', '2026-05-09', '2026-06-24', 'Automotive tools batch', 'Heavy load shipment', 'Net 45', 16000.00, 1000.00, 1530.00, 1530.00, 0.00, 20060.00, 'Draft', NOW(), 25, 25, 3),
('ME/2025-26/026', 'Laura Rossi', '2026-05-10', '2026-05-25', 'Design software licenses', '', 'Net 15', 300.00, 50.00, 31.50, 31.50, 0.00, 413.00, 'Paid', NOW(), 26, 26, 3),
('ME/2025-26/027', 'Tariq Khan', '2026-05-11', '2026-06-11', 'Vehicle fleet maintenance', '', 'Net 30', 6000.00, 0.00, 540.00, 540.00, 0.00, 7080.00, 'Draft', NOW(), 27, 27, 3),
('ME/2025-26/028', 'Neha Joshi', '2026-05-12', '2026-05-27', 'Medical equipment supply', 'Fragile items', 'Net 15', 14500.00, 500.00, 0.00, 0.00, 2700.00, 17700.00, 'Paid', NOW(), 28, 28, 3),
('ME/2025-26/029', 'Omar Al-Fayed', '2026-05-13', '2026-06-13', 'Bulk export commodities', '', 'Net 30', 8900.00, 100.00, 810.00, 810.00, 0.00, 10620.00, 'Partial', NOW(), 29, 29, 3),
('ME/2025-26/030', 'Ritu Phogat', '2026-05-14', '2026-06-29', 'Sporting goods manufacturing', '', 'Net 45', 25000.00, 0.00, 0.00, 0.00, 4500.00, 29500.00, 'Paid', NOW(), 30, 30, 3);

-- --------------------------------------------------------
-- Table structure for table `invoice_items`
-- --------------------------------------------------------
CREATE TABLE `invoice_items` (
  `item_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `item_detail` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `uom_amount` decimal(10,2) DEFAULT 0.00,
  `uom_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `invoice_items` (`item_id`, `invoice_id`, `item_detail`, `quantity`, `rate`, `discount`, `amount`, `uom_amount`, `uom_description`) VALUES
(1, 1, 'Industrial Bolt', 10, 120.00, 0, 1200.00, 0.00, 'pcs'),
(2, 2, 'Steel Plate', 10, 500.00, 0, 5000.00, 0.00, 'kg'),
(3, 3, 'Hydraulic Pump', 1, 2500.00, 0, 2500.00, 0.00, 'pcs'),
(4, 4, 'Electrical Cable', 100, 20.00, 0, 2000.00, 0.00, 'm'),
(5, 5, 'Aluminium Sheet', 10, 300.00, 0, 3000.00, 0.00, 'kg'),
(6, 6, 'Installation Service', 1, 1500.00, 0, 1500.00, 0.00, NULL),
(7, 7, 'Plastic Granules', 50, 30.00, 0, 1500.00, 0.00, 'kg'),
(8, 8, 'Consultancy', 1, 5000.00, 0, 5000.00, 0.00, NULL),
(9, 9, 'Textile Order', 5, 500.00, 0, 2500.00, 0.00, 'kg'),
(10, 10, 'Consultancy US', 1, 3000.00, 0, 3000.00, 0.00, NULL),
(11, 11, 'Forklift Rental', 2, 4000.00, 0, 8000.00, 0.00, 'pcs'),
(12, 12, 'Retail Shelving Unit', 5, 900.00, 0, 4500.00, 0.00, 'pcs'),
(13, 13, 'CNC Machine Spindle', 3, 4000.00, 0, 12000.00, 0.00, 'pcs'),
(14, 14, 'Cotton Yarn', 40, 80.00, 0, 3200.00, 0.00, 'kg'),
(15, 15, 'Surgical Steel Tubing', 67, 100.00, 0, 6700.00, 0.00, 'm'),
(16, 16, 'Strategy Consulting', 10, 2100.00, 0, 21000.00, 0.00, 'hours'),
(17, 17, 'Gearbox Assembly', 2, 2700.00, 0, 5400.00, 0.00, 'pcs'),
(18, 18, 'Server Rack', 4, 2450.00, 0, 9800.00, 0.00, 'pcs'),
(19, 19, 'LED Studio Light', 10, 150.00, 0, 1500.00, 0.00, 'pcs'),
(20, 20, 'Patent Licensing Fee', 1, 8500.00, 0, 8500.00, 0.00, NULL),
(21, 21, 'Loom Motor Maintenance', 5, 2200.00, 0, 11000.00, 0.00, 'hours'),
(22, 22, 'Ergonomic Office Chair', 10, 250.00, 0, 2500.00, 0.00, 'pcs'),
(23, 23, 'Servo Motor', 8, 600.00, 0, 4800.00, 0.00, 'pcs'),
(24, 24, 'Financial Audit', 50, 150.00, 0, 7500.00, 0.00, 'hours'),
(25, 25, 'Pneumatic Wrench', 20, 800.00, 0, 16000.00, 0.00, 'pcs'),
(26, 26, 'CAD Software License', 2, 150.00, 0, 300.00, 0.00, 'pcs'),
(27, 27, 'Truck Engine Overhaul', 2, 3000.00, 0, 6000.00, 0.00, 'pcs'),
(28, 28, 'Ultrasound Machine', 1, 14500.00, 0, 14500.00, 0.00, 'pcs'),
(29, 29, 'Bulk Export Commodities', 100, 89.00, 0, 8900.00, 0.00, 'kg'),
(30, 30, 'Professional Cricket Bat', 50, 500.00, 0, 25000.00, 0.00, 'pcs');

-- --------------------------------------------------------
-- Table structure for table `payment_entries`
-- --------------------------------------------------------
CREATE TABLE `payment_entries` (
  `payment_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `invoice_number` varchar(20) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` enum('Online','Cash','Cheque') NOT NULL DEFAULT 'Cash',
  `currency` varchar(10) NOT NULL DEFAULT 'INR',
  `amount` decimal(10,2) NOT NULL,
  `invoice_total` decimal(10,2) NOT NULL,
  `remaining_balance` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `financial_year_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_entries` (`payment_id`, `invoice_id`, `invoice_number`, `payment_date`, `payment_mode`, `currency`, `amount`, `invoice_total`, `remaining_balance`, `created_at`, `updated_at`, `financial_year_id`) VALUES
(1, 1, 'ME/2025-26/001', '2026-04-10', 'Online', 'INR', 500.00, 1416.00, 916.00, NOW(), NOW(), 3),
(2, 2, 'ME/2025-26/002', '2026-04-12', 'Cash', 'INR', 2000.00, 5900.00, 3900.00, NOW(), NOW(), 3),
(3, 3, 'ME/2025-26/003', '2026-04-15', 'Cheque', 'INR', 1000.00, 2950.00, 1950.00, NOW(), NOW(), 3),
(4, 4, 'ME/2025-26/004', '2026-04-18', 'Cash', 'INR', 1000.00, 2360.00, 1360.00, NOW(), NOW(), 3),
(5, 5, 'ME/2025-26/005', '2026-04-20', 'Online', 'INR', 1500.00, 3540.00, 2040.00, NOW(), NOW(), 3),
(6, 6, 'ME/2025-26/006', '2026-04-22', 'Cash', 'INR', 500.00, 1770.00, 1270.00, NOW(), NOW(), 3),
(7, 7, 'ME/2025-26/007', '2026-04-25', 'Online', 'INR', 1000.00, 1770.00, 770.00, NOW(), NOW(), 3),
(8, 8, 'ME/2025-26/008', '2026-04-26', 'Cheque', 'INR', 3000.00, 6500.00, 3500.00, NOW(), NOW(), 3),
(9, 9, 'ME/2025-26/009', '2026-04-27', 'Cash', 'INR', 1000.00, 2950.00, 1950.00, NOW(), NOW(), 3),
(10, 10, 'ME/2025-26/010', '2026-04-28', 'Online', 'INR', 1540.00, 3540.00, 2000.00, NOW(), NOW(), 3),
(11, 11, 'ME/2025-26/011', '2026-04-30', 'Cheque', 'INR', 4440.00, 9440.00, 5000.00, NOW(), NOW(), 3),
(12, 12, 'ME/2025-26/012', '2026-05-02', 'Online', 'INR', 5900.00, 5900.00, 0.00, NOW(), NOW(), 3),
(13, 13, 'ME/2025-26/013', '2026-05-05', 'Online', 'INR', 5000.00, 14160.00, 9160.00, NOW(), NOW(), 3),
(14, 14, 'ME/2025-26/014', '2026-05-10', 'Cash', 'INR', 1776.00, 3776.00, 2000.00, NOW(), NOW(), 3),
(15, 15, 'ME/2025-26/015', '2026-05-12', 'Cheque', 'INR', 8260.00, 8260.00, 0.00, NOW(), NOW(), 3),
(16, 16, 'ME/2025-26/016', '2026-05-15', 'Online', 'INR', 10000.00, 24780.00, 14780.00, NOW(), NOW(), 3),
(17, 17, 'ME/2025-26/017', '2026-05-16', 'Online', 'INR', 6490.00, 6490.00, 0.00, NOW(), NOW(), 3),
(18, 18, 'ME/2025-26/018', '2026-05-18', 'Cheque', 'INR', 6000.00, 11800.00, 5800.00, NOW(), NOW(), 3),
(19, 19, 'ME/2025-26/019', '2026-05-20', 'Cash', 'INR', 1770.00, 1770.00, 0.00, NOW(), NOW(), 3),
(20, 20, 'ME/2025-26/020', '2026-05-22', 'Online', 'INR', 5030.00, 10030.00, 5000.00, NOW(), NOW(), 3),
(21, 21, 'ME/2025-26/021', '2026-05-23', 'Cheque', 'INR', 12980.00, 12980.00, 0.00, NOW(), NOW(), 3),
(22, 22, 'ME/2025-26/022', '2026-05-25', 'Online', 'INR', 1540.00, 3540.00, 2000.00, NOW(), NOW(), 3),
(23, 23, 'ME/2025-26/023', '2026-05-26', 'Cash', 'INR', 2000.00, 5664.00, 3664.00, NOW(), NOW(), 3),
(24, 24, 'ME/2025-26/024', '2026-05-27', 'Online', 'INR', 8850.00, 8850.00, 0.00, NOW(), NOW(), 3),
(25, 25, 'ME/2025-26/025', '2026-05-28', 'Cheque', 'INR', 10060.00, 20060.00, 10000.00, NOW(), NOW(), 3),
(26, 26, 'ME/2025-26/026', '2026-05-29', 'Online', 'INR', 413.00, 413.00, 0.00, NOW(), NOW(), 3);

-- --------------------------------------------------------
-- Table structure for table `purchase_orders`
-- --------------------------------------------------------
CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL,
  `purchase_order_no` varchar(50) DEFAULT NULL,
  `delivery_to` enum('organization','customer') DEFAULT NULL,
  `delivery_address` text DEFAULT NULL,
  `vendor_name` varchar(100) DEFAULT NULL,
  `purchase_order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `payment_terms` varchar(100) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `customer_notes` text DEFAULT NULL,
  `terms_and_conditions` text DEFAULT NULL,
  `sub_total` decimal(10,2) DEFAULT NULL,
  `freight` decimal(10,2) DEFAULT 0.00,
  `cgst` decimal(10,2) DEFAULT NULL,
  `sgst` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `vendor_id` int(11) DEFAULT NULL,
  `financial_year_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `purchase_orders` (`id`, `purchase_order_no`, `delivery_to`, `delivery_address`, `vendor_name`, `purchase_order_date`, `delivery_date`, `payment_terms`, `due_date`, `customer_notes`, `terms_and_conditions`, `sub_total`, `freight`, `cgst`, `sgst`, `total`, `attachment`, `created_at`, `vendor_id`, `financial_year_id`) VALUES
(1, 'PO/2025-26/001', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Raju', '2026-05-08', '2026-05-15', 'Net 30', '2026-05-30', 'Urgent delivery', '', 528840.00, 0.00, 47595.60, 47595.60, 624031.20, NULL, NOW(), 1, 3),
(2, 'PO/2025-26/002', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Raju Ramesh Pise', '2026-05-10', '2026-05-18', 'Net 45', '2026-06-05', '', '', 28526.00, 0.00, 2567.34, 2567.34, 33660.68, NULL, NOW(), 2, 3),
(3, 'PO/2025-26/003', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Kasturi Enterprises', '2026-05-12', '2026-05-20', 'Due end of month', '2026-06-10', '', '', 381745.00, 0.00, 34357.05, 34357.05, 450459.10, NULL, NOW(), 3, 3),
(4, 'PO/2025-26/004', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Akshay Wadi', '2026-05-14', '2026-05-22', 'Net 60', '2026-06-14', '', '', 7984.00, 0.00, 718.56, 718.56, 9421.12, NULL, NOW(), 5, 3),
(5, 'PO/2025-26/005', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Starte Bap', '2026-05-16', '2026-05-24', 'Net 30', '2026-06-16', '', '', 62925.00, 0.00, 5663.25, 5663.25, 74251.50, NULL, NOW(), 6, 3),
(6, 'PO/2025-26/006', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Pise', '2026-05-18', '2026-05-26', 'Due end of month', '2026-06-18', '', '', 55374.00, 0.00, 4983.66, 4983.66, 65341.32, NULL, NOW(), 4, 3),
(7, 'PO/2025-26/007', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Pise', '2026-05-20', '2026-05-28', 'Net 30', '2026-06-20', '', '', 73832.00, 0.00, 6644.88, 6644.88, 87121.76, NULL, NOW(), 4, 3),
(8, 'PO/2025-26/008', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Pise', '2026-05-22', '2026-05-30', 'Due end of month', '2026-06-22', '', '', 73832.00, 0.00, 6644.88, 6644.88, 87121.76, NULL, NOW(), 4, 3),
(9, 'PO/2025-26/009', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Raju', '2026-05-24', '2026-06-02', 'Net 30', '2026-06-24', 'Please include quality testing certificates.', '', 20000.00, 0.00, 1800.00, 1800.00, 23600.00, NULL, NOW(), 1, 3),
(10, 'PO/2025-26/010', 'customer', 'Rajesh Kumar, Mumbai, Maharashtra, 400001', 'Raju Ramesh Pise', '2026-05-25', '2026-06-03', 'Net 45', '2025-11-09', 'Direct ship to customer site', '', 15000.00, 500.00, 1350.00, 1350.00, 18200.00, NULL, NOW(), 2, 3),
(11, 'PO/2025-26/011', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Kasturi Enterprises', '2026-05-26', '2026-06-04', 'Net 30', '2026-06-26', '', '', 50000.00, 0.00, 4500.00, 4500.00, 59000.00, NULL, NOW(), 3, 3),
(12, 'PO/2025-26/012', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Akshay Wadi', '2026-05-27', '2026-06-05', 'Net 60', '2025-11-26', '', '', 12000.00, 0.00, 1080.00, 1080.00, 14160.00, NULL, NOW(), 5, 3),
(13, 'PO/2025-26/013', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Starte Bap', '2026-05-28', '2026-06-06', 'Due end of month', '2026-06-31', 'Fragile components, pack carefully', '', 8000.00, 200.00, 720.00, 720.00, 9640.00, NULL, NOW(), 6, 3),
(14, 'PO/2025-26/014', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Pise', '2026-05-29', '2026-06-07', 'Net 30', '2026-06-29', '', '', 25000.00, 0.00, 2250.00, 2250.00, 29500.00, NULL, NOW(), 4, 3),
(15, 'PO/2025-26/015', 'customer', 'Sonal Sharma, Pune, Maharashtra, 411001', 'Anush Raju', '2026-05-30', '2026-06-08', 'Net 45', '2025-11-14', 'Call before delivery', '', 30000.00, 1000.00, 2700.00, 2700.00, 36400.00, NULL, NOW(), 1, 3),
(16, 'PO/2025-26/016', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Raju Ramesh Pise', '2026-06-01', '2026-06-09', 'Net 30', '2026-06-31', '', 'Standard PO Terms Apply', 18000.00, 0.00, 1620.00, 1620.00, 21240.00, NULL, NOW(), 2, 3),
(17, 'PO/2025-26/017', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Kasturi Enterprises', '2026-06-02', '2026-06-10', 'Net 60', '2025-12-01', '', '', 42000.00, 0.00, 3780.00, 3780.00, 49560.00, NULL, NOW(), 3, 3),
(18, 'PO/2025-26/018', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Akshay Wadi', '2026-06-03', '2026-06-11', 'Due end of month', '2026-06-31', '', '', 11000.00, 0.00, 990.00, 990.00, 12980.00, NULL, NOW(), 5, 3),
(19, 'PO/2025-26/019', 'customer', 'Anil Patel, Nagpur, Maharashtra, 440001', 'Starte Bap', '2026-06-04', '2026-06-12', 'Net 30', '2025-11-03', 'Deliver to new warehouse', '', 55000.00, 1500.00, 4950.00, 4950.00, 66400.00, NULL, NOW(), 6, 3),
(20, 'PO/2025-26/020', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Pise', '2026-06-05', '2026-06-13', 'Net 45', '2025-11-19', '', '', 75000.00, 0.00, 6750.00, 6750.00, 88500.00, NULL, NOW(), 4, 3),
(21, 'PO/2025-26/021', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Raju', '2026-06-06', '2026-06-14', 'Net 30', '2025-11-05', 'Bulk order - ensure pallets are secure', '', 90000.00, 0.00, 8100.00, 8100.00, 106200.00, NULL, NOW(), 1, 3),
(22, 'PO/2025-26/022', 'customer', 'Nisha Gupta, Nagpur, Maharashtra, 440001', 'Raju Ramesh Pise', '2026-06-07', '2026-06-15', 'Net 60', '2025-12-06', 'Urgent electronics supply', '', 60000.00, 1000.00, 5400.00, 5400.00, 71800.00, NULL, NOW(), 2, 3),
(23, 'PO/2025-26/023', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Kasturi Enterprises', '2026-06-08', '2026-06-16', 'Due end of month', '2026-06-31', '', '', 13000.00, 0.00, 1170.00, 1170.00, 15340.00, NULL, NOW(), 3, 3),
(24, 'PO/2025-26/024', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Akshay Wadi', '2026-06-09', '2026-06-17', 'Net 30', '2025-11-08', '', '', 27000.00, 500.00, 2430.00, 2430.00, 32360.00, NULL, NOW(), 5, 3),
(25, 'PO/2025-26/025', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Starte Bap', '2026-06-10', '2026-06-18', 'Net 45', '2025-11-24', '', '', 34000.00, 0.00, 3060.00, 3060.00, 40120.00, NULL, NOW(), 6, 3),
(26, 'PO/2025-26/026', 'customer', 'Deepak Verma, Kolhapur, Maharashtra, 416001', 'Anush Pise', '2026-06-11', '2026-06-19', 'Net 30', '2025-11-10', 'Heavy duty materials transport', '', 88000.00, 2000.00, 7920.00, 7920.00, 105840.00, NULL, NOW(), 4, 3),
(27, 'PO/2025-26/027', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Anush Raju', '2026-06-12', '2026-06-20', 'Net 60', '2025-12-11', '', '', 41000.00, 0.00, 3690.00, 3690.00, 48380.00, NULL, NOW(), 1, 3),
(28, 'PO/2025-26/028', 'organization', 'Laxmi Enterprises, Nagpur, Maharashtra, 200145', 'Kasturi Enterprises', '2026-06-13', '2026-06-21', 'Due end of month', '2026-06-31', '', 'Ensure packaging matches compliance standards', 105000.00, 0.00, 9450.00, 9450.00, 123900.00, NULL, NOW(), 3, 3);

-- --------------------------------------------------------
-- Table structure for table `purchase_order_items`
-- --------------------------------------------------------
CREATE TABLE `purchase_order_items` (
  `id` int(11) NOT NULL,
  `purchase_order_id` int(11) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `uom_amount` decimal(10,2) DEFAULT 0.00,
  `uom_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `purchase_order_items` (`id`, `purchase_order_id`, `item_name`, `qty`, `rate`, `discount`, `amount`, `uom_amount`, `uom_description`) VALUES
(1, 1, 'Industrial Bolt', 500, 120.00, 0.00, 60000.00, 0.00, 'pcs'),
(2, 1, 'Steel Plate', 200, 500.00, 0.00, 100000.00, 0.00, 'kg'),
(3, 2, 'Electrical Cable', 1000, 20.00, 0.00, 20000.00, 0.00, 'm'),
(4, 3, 'Aluminium Sheet', 300, 300.00, 0.00, 90000.00, 0.00, 'kg'),
(5, 4, 'Hydraulic Pump', 5, 2500.00, 0.00, 12500.00, 0.00, 'pcs'),
(6, 5, 'Installation Service', 1, 1500.00, 0.00, 1500.00, 0.00, NULL),
(7, 6, 'Plastic Granules', 200, 30.00, 0.00, 6000.00, 0.00, 'kg'),
(8, 7, 'Consultancy', 1, 5000.00, 0.00, 5000.00, 0.00, NULL),
(9, 8, 'Textile Order', 50, 500.00, 0.00, 25000.00, 0.00, 'kg'),
(10, 9, 'Titanium Drill Bit', 40, 500.00, 0.00, 20000.00, 0.00, 'pcs'),
(11, 10, 'Safety Helmets', 100, 150.00, 0.00, 15000.00, 0.00, 'pcs'),
(12, 11, 'Heavy Duty Bearings', 20, 2500.00, 0.00, 50000.00, 0.00, 'pcs'),
(13, 12, 'PVC Pipe 2 inch', 200, 60.00, 0.00, 12000.00, 0.00, 'm'),
(14, 13, 'Copper Wire Roll', 10, 800.00, 0.00, 8000.00, 0.00, 'kg'),
(15, 14, 'Stainless Steel Screws', 100, 250.00, 0.00, 25000.00, 0.00, 'box'),
(16, 15, 'Concrete Mix', 100, 300.00, 0.00, 30000.00, 0.00, 'bags'),
(17, 16, 'Rubber Gaskets', 600, 30.00, 0.00, 18000.00, 0.00, 'pcs'),
(18, 17, 'LED Panel Light', 35, 1200.00, 0.00, 42000.00, 0.00, 'pcs'),
(19, 18, 'Fiberglass Insulation', 110, 100.00, 0.00, 11000.00, 0.00, 'm'),
(20, 19, 'Generator 5kVA', 1, 55000.00, 0.00, 55000.00, 0.00, 'pcs'),
(21, 20, 'Welding Rods', 500, 150.00, 0.00, 75000.00, 0.00, 'kg'),
(22, 21, 'Industrial Lubricant', 300, 300.00, 0.00, 90000.00, 0.00, 'liters'),
(23, 22, 'Office Chair', 20, 3000.00, 0.00, 60000.00, 0.00, 'pcs'),
(24, 23, 'Graphic Design Software', 10, 1300.00, 0.00, 13000.00, 0.00, 'licenses'),
(25, 24, 'Cloud Hosting Setup', 9, 3000.00, 0.00, 27000.00, 0.00, 'hours'),
(26, 25, 'Annual Maintenance', 2, 17000.00, 0.00, 34000.00, 0.00, 'years'),
(27, 26, 'Machinery Transport', 880, 100.00, 0.00, 88000.00, 0.00, 'km'),
(28, 27, 'On-site Troubleshooting', 41, 1000.00, 0.00, 41000.00, 0.00, 'hours'),
(29, 28, 'Software Audit', 15, 7000.00, 0.00, 105000.00, 0.00, 'hours');

-- --------------------------------------------------------
-- Table structure for table `quotation`
-- --------------------------------------------------------
CREATE TABLE `quotation` (
  `quotation_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `quotation_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `customer_notes` text DEFAULT NULL,
  `terms_and_conditions` text DEFAULT NULL,
  `sub_total` double DEFAULT NULL,
  `freight` decimal(10,2) DEFAULT 0.00,
  `cgst` double DEFAULT NULL,
  `sgst` double DEFAULT NULL,
  `igst` decimal(10,2) DEFAULT 0.00,
  `attachment_url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `grand_total` int(255) DEFAULT NULL,
  `status` enum('Draft','Sent') DEFAULT 'Draft',
  `quote_number` varchar(20) DEFAULT NULL,
  `financial_year_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `quotation` (`quotation_id`, `customer_name`, `quotation_date`, `expiry_date`, `subject`, `customer_notes`, `terms_and_conditions`, `sub_total`, `freight`, `cgst`, `sgst`, `igst`, `attachment_url`, `created_at`, `grand_total`, `status`, `quote_number`, `financial_year_id`) VALUES
(1, 'Rajesh Kumar', '2026-04-01', '2026-04-15', 'Industrial Bolt Supply Quote', 'Please review and confirm', '', 1200.00, 0.00, 108.00, 108.00, 0.00, NULL, NOW(), 1416, 'Draft', 'QT-2025-26-001', 3),
(2, 'Sonal Sharma', '2026-04-03', '2026-04-18', 'Steel Plate Quote', '', '', 5000.00, 0.00, 450.00, 450.00, 0.00, NULL, NOW(), 5900, 'Draft', 'QT-2025-26-002', 3),
(3, 'Dr. Rahul Mehra', '2026-04-04', '2026-04-19', 'Hydraulic Pump Quote', '', '', 2500.00, 0.00, 0.00, 0.00, 450.00, NULL, NOW(), 2950, 'Draft', 'QT-2025-26-003', 3),
(4, 'Anil Patel', '2026-04-06', '2026-04-21', 'Electrical Cable Quote', '', '', 2000.00, 0.00, 180.00, 180.00, 0.00, NULL, NOW(), 2360, 'Draft', 'QT-2025-26-004', 3),
(5, 'Vijay Singh', '2026-04-08', '2026-04-23', 'Aluminium Sheet Quote', '', '', 3000.00, 0.00, 270.00, 270.00, 0.00, NULL, NOW(), 3540, 'Draft', 'QT-2025-26-005', 3),
(6, 'Nisha Gupta', '2026-04-10', '2026-04-25', 'Installation Service Quote', '', '', 1500.00, 0.00, 135.00, 135.00, 0.00, NULL, NOW(), 1770, 'Draft', 'QT-2025-26-006', 3),
(7, 'Deepak Verma', '2026-04-12', '2026-04-27', 'Plastic Granules Quote', '', 'Net 30', 10000.00, 0.00, 900.00, 900.00, 0.00, NULL, NOW(), 11800, 'Sent', 'QT-2025-26-007', 3),
(8, 'Emily Johnson', '2026-04-14', '2026-04-29', 'Export Consultancy Services', 'For international branch', 'Net 45', 12000.00, 0.00, 0.00, 0.00, 2160.00, NULL, NOW(), 14160, 'Sent', 'QT-2025-26-008', 3),
(9, 'Anusha Rao', '2026-04-15', '2026-04-30', 'Textile Machinery Spare Parts', '', '', 3500.00, 0.00, 315.00, 315.00, 0.00, NULL, NOW(), 4130, 'Draft', 'QT-2025-26-009', 3),
(10, 'Alice Smith', '2026-04-16', '2026-04-31', 'Global Infrastructure Audit', '', 'Net 30', 8500.00, 0.00, 0.00, 0.00, 1530.00, NULL, NOW(), 10030, 'Sent', 'QT-2025-26-010', 3),
(11, 'Karan Desai', '2026-04-17', '2026-05-01', 'Logistics Equipment Quote', 'Includes delivery to warehouse', 'Net 15', 4000.00, 500.00, 405.00, 405.00, 0.00, NULL, NOW(), 5310, 'Draft', 'QT-2025-26-011', 3),
(12, 'Priya Kadam', '2026-04-18', '2026-05-02', 'Retail Shelving Units', '', '', 5000.00, 0.00, 450.00, 450.00, 0.00, NULL, NOW(), 5900, 'Sent', 'QT-2025-26-012', 3),
(13, 'David Chen', '2026-04-19', '2026-05-03', 'Imported CNC Parts', '', 'Net 15', 15000.00, 0.00, 0.00, 0.00, 2700.00, NULL, NOW(), 17700, 'Draft', 'QT-2025-26-013', 3),
(14, 'Lata Mangesh', '2026-04-20', '2026-05-04', 'Bulk Raw Materials Supply', '', 'Net 30', 6000.00, 0.00, 540.00, 540.00, 0.00, NULL, NOW(), 7080, 'Sent', 'QT-2025-26-014', 3),
(15, 'Vikram Batra', '2026-04-21', '2026-05-05', 'Pharmaceutical Grade Steel Tubing', 'Must include test certificates', 'Net 30', 9000.00, 0.00, 810.00, 810.00, 0.00, NULL, NOW(), 10620, 'Draft', 'QT-2025-26-015', 3),
(16, 'Sarah Jenkins', '2026-04-22', '2026-05-06', 'Strategy Consulting Retainer', '', 'Net 15', 20000.00, 0.00, 0.00, 0.00, 3600.00, NULL, NOW(), 23600, 'Sent', 'QT-2025-26-016', 3),
(17, 'Amit Shah', '2026-04-23', '2026-05-07', 'Gearbox Assembly Components', '', '', 3000.00, 200.00, 288.00, 288.00, 0.00, NULL, NOW(), 3776, 'Draft', 'QT-2025-26-017', 3),
(18, 'Kavita Reddy', '2026-04-24', '2026-05-08', 'Server Rack Quote', 'Installation not included', 'Net 30', 11000.00, 0.00, 990.00, 990.00, 0.00, NULL, NOW(), 12980, 'Sent', 'QT-2025-26-018', 3),
(19, 'Manoj Bajpayee', '2026-04-25', '2026-05-09', 'LED Studio Lighting Quote', '', '', 7500.00, 0.00, 675.00, 675.00, 0.00, NULL, NOW(), 8850, 'Draft', 'QT-2025-26-019', 3),
(20, 'Hans Muller', '2026-04-26', '2026-05-10', 'Patent Licensing Framework', '', 'Net 30', 25000.00, 0.00, 0.00, 0.00, 4500.00, NULL, NOW(), 29500, 'Sent', 'QT-2025-26-020', 3),
(21, 'Sneha Kapoor', '2026-04-27', '2026-05-11', 'Loom Motor Maintenance Quote', '', '', 5500.00, 0.00, 495.00, 495.00, 0.00, NULL, NOW(), 6490, 'Draft', 'QT-2025-26-021', 3),
(22, 'Rohan Das', '2026-04-28', '2026-05-12', 'Ergonomic Office Chairs', '', 'Net 15', 13000.00, 0.00, 1170.00, 1170.00, 0.00, NULL, NOW(), 15340, 'Sent', 'QT-2025-26-022', 3),
(23, 'Kenji Sato', '2026-04-29', '2026-05-13', 'Servo Motor Import Quote', 'Includes customs handling', 'Net 45', 32000.00, 0.00, 0.00, 0.00, 5760.00, NULL, NOW(), 37760, 'Sent', 'QT-2025-26-023', 3),
(24, 'Pooja Iyer', '2026-04-30', '2026-05-14', 'Financial Audit Services', '', '', 4500.00, 0.00, 405.00, 405.00, 0.00, NULL, NOW(), 5310, 'Draft', 'QT-2025-26-024', 3),
(25, 'Gaurav Tiwari', '2026-04-31', '2026-05-15', 'Pneumatic Wrenches Bulk Quote', 'Heavy tooling shipment', 'Net 30', 18000.00, 1000.00, 1710.00, 1710.00, 0.00, NULL, NOW(), 22420, 'Sent', 'QT-2025-26-025', 3),
(26, 'Laura Rossi', '2026-05-01', '2026-05-16', 'CAD Software Licenses', '', 'Net 15', 22000.00, 0.00, 0.00, 0.00, 3960.00, NULL, NOW(), 25960, 'Draft', 'QT-2025-26-026', 3);

-- --------------------------------------------------------
-- Table structure for table `quotation_items`
-- --------------------------------------------------------
CREATE TABLE `quotation_items` (
  `item_id` int(11) NOT NULL,
  `quotation_id` int(11) DEFAULT NULL,
  `item_detail` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `uom_amount` decimal(10,2) DEFAULT 0.00,
  `uom_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `quotation_items` (`item_id`, `quotation_id`, `item_detail`, `quantity`, `rate`, `discount`, `amount`, `uom_amount`, `uom_description`) VALUES
(1, 1, 'Industrial Bolt', 10, 120.00, 0, 1200.00, 0.00, 'pcs'),
(2, 2, 'Steel Plate', 10, 500.00, 0, 5000.00, 0.00, 'kg'),
(3, 3, 'Hydraulic Pump', 1, 2500.00, 0, 2500.00, 0.00, 'pcs'),
(4, 4, 'Electrical Cable', 100, 20.00, 0, 2000.00, 0.00, 'm'),
(5, 5, 'Aluminium Sheet', 10, 300.00, 0, 3000.00, 0.00, 'kg'),
(6, 6, 'Installation Service', 1, 1500.00, 0, 1500.00, 0.00, NULL),
(7, 7, 'Plastic Granules HD', 200, 50.00, 0, 10000.00, 0.00, 'kg'),
(8, 8, 'Export Consultancy Services', 1, 12000.00, 0, 12000.00, 0.00, NULL),
(9, 9, 'Textile Machinery Spares', 10, 350.00, 0, 3500.00, 0.00, 'pcs'),
(10, 10, 'Global Infrastructure Audit', 1, 8500.00, 0, 8500.00, 0.00, NULL),
(11, 11, 'Heavy Duty Pallet Jack', 2, 2000.00, 0, 4000.00, 0.00, 'pcs'),
(12, 12, 'Retail Shelving Unit', 5, 1000.00, 0, 5000.00, 0.00, 'pcs'),
(13, 13, 'CNC Spindle Motor', 3, 5000.00, 0, 15000.00, 0.00, 'pcs'),
(14, 14, 'Bulk Cotton Roll', 100, 60.00, 0, 6000.00, 0.00, 'kg'),
(15, 15, 'Pharma Grade Steel Tubing', 90, 100.00, 0, 9000.00, 0.00, 'm'),
(16, 16, 'Strategy Consulting Retainer', 10, 2000.00, 0, 20000.00, 0.00, 'hours'),
(17, 17, 'Gearbox Assembly Component', 4, 750.00, 0, 3000.00, 0.00, 'pcs'),
(18, 18, 'Server Rack 42U', 2, 5500.00, 0, 11000.00, 0.00, 'pcs'),
(19, 19, 'LED Studio Light', 15, 500.00, 0, 7500.00, 0.00, 'pcs'),
(20, 20, 'Patent Licensing Framework', 1, 25000.00, 0, 25000.00, 0.00, NULL),
(21, 21, 'Loom Motor Maintenance', 1, 5500.00, 0, 5500.00, 0.00, NULL),
(22, 22, 'Ergonomic Office Chair', 5, 2600.00, 0, 13000.00, 0.00, 'pcs'),
(23, 23, 'Servo Motor Assembly', 8, 4000.00, 0, 32000.00, 0.00, 'pcs'),
(24, 24, 'Financial Audit Hours', 30, 150.00, 0, 4500.00, 0.00, 'hours'),
(25, 25, 'Pneumatic Wrench', 20, 900.00, 0, 18000.00, 0.00, 'pcs'),
(26, 26, 'CAD Software License', 11, 2000.00, 0, 22000.00, 0.00, 'licenses');

-- --------------------------------------------------------
-- Table structure for table `work_orders`
-- --------------------------------------------------------
CREATE TABLE `work_orders` (
  `work_order_id` int(11) NOT NULL,
  `work_order_number` varchar(50) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `work_order_date` date NOT NULL,
  `due_date` date NOT NULL,
  `payment_terms` varchar(100) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `customer_notes` text DEFAULT NULL,
  `terms_and_conditions` text DEFAULT NULL,
  `attachment_url` varchar(255) DEFAULT NULL,
  `sub_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cgst` decimal(10,2) NOT NULL DEFAULT 0.00,
  `sgst` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(50) DEFAULT 'Draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `purchase_order_number` varchar(100) DEFAULT NULL,
  `purchase_order_date` date DEFAULT NULL,
  `financial_year_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `work_orders` (`work_order_id`, `work_order_number`, `customer_name`, `work_order_date`, `due_date`, `payment_terms`, `subject`, `customer_notes`, `terms_and_conditions`, `attachment_url`, `sub_total`, `cgst`, `sgst`, `grand_total`, `status`, `created_at`, `updated_at`, `purchase_order_number`, `purchase_order_date`, `financial_year_id`) VALUES
(1, 'WO/2025-26/001', 'Rajesh Kumar', '2026-04-05', '2026-04-20', 'Due end of month', 'Bolt procurement', '', '', NULL, 60000.00, 5400.00, 5400.00, 70800.00, 'Draft', NOW(), NOW(), 'PO/2025-26/001', '2026-05-08', 3),
(2, 'WO/2025-26/002', 'Sonal Sharma', '2026-04-07', '2026-04-22', 'Net 30', 'Steel plate order', '', '', NULL, 100000.00, 9000.00, 9000.00, 118000.00, 'Draft', NOW(), NOW(), 'PO/2025-26/002', '2026-05-10', 3),
(3, 'WO/2025-26/003', 'Dr. Rahul Mehra', '2026-04-09', '2026-04-24', 'Net 45', 'Hydraulic pump installation', '', '', NULL, 12500.00, 1125.00, 1125.00, 14750.00, 'Draft', NOW(), NOW(), 'PO/2025-26/003', '2026-05-12', 3),
(4, 'WO/2025-26/004', 'Anil Patel', '2026-04-11', '2026-04-26', 'Net 60', 'Electrical cable supply', '', '', NULL, 20000.00, 1800.00, 1800.00, 23600.00, 'Draft', NOW(), NOW(), 'PO/2025-26/004', '2026-05-14', 3),
(5, 'WO/2025-26/005', 'Vijay Singh', '2026-04-13', '2026-04-28', 'Net 30', 'Aluminium sheet order', '', '', NULL, 90000.00, 8100.00, 8100.00, 106200.00, 'Draft', NOW(), NOW(), 'PO/2025-26/005', '2026-05-16', 3),
(6, 'WO/2025-26/006', 'Nisha Gupta', '2026-04-15', '2026-04-30', 'Net 45', 'Installation service', '', '', NULL, 1500.00, 135.00, 135.00, 1770.00, 'Draft', NOW(), NOW(), 'PO/2025-26/006', '2026-05-18', 3),
(7, 'WO/2025-26/007', 'Deepak Verma', '2026-04-17', '2026-05-01', 'Net 30', 'Plastic granules processing', 'Urgent priority', '', NULL, 10000.00, 900.00, 900.00, 11800.00, 'In Progress', NOW(), NOW(), 'PO/2025-26/007', '2026-05-20', 3),
(8, 'WO/2025-26/008', 'Emily Johnson', '2026-04-19', '2026-05-03', 'Net 45', 'Export documentation service', '', '', NULL, 15000.00, 1350.00, 1350.00, 17700.00, 'Completed', NOW(), NOW(), 'PO/2025-26/008', '2026-05-22', 3),
(9, 'WO/2025-26/009', 'Anusha Rao', '2026-04-21', '2026-05-05', 'Due end of month', 'Textile loom maintenance', '', '', NULL, 25000.00, 2250.00, 2250.00, 29500.00, 'Draft', NOW(), NOW(), 'PO/2025-26/009', '2026-05-24', 3),
(10, 'WO/2025-26/010', 'Alice Smith', '2026-04-23', '2026-05-07', 'Net 15', 'Audit preparation', 'On-site required', '', NULL, 5000.00, 450.00, 450.00, 5900.00, 'In Progress', NOW(), NOW(), 'PO/2025-26/010', '2026-05-25', 3),
(11, 'WO/2025-26/011', 'Karan Desai', '2026-04-25', '2026-05-09', 'Net 30', 'Warehouse logistics optimization', '', 'Standard logistics terms', NULL, 40000.00, 3600.00, 3600.00, 47200.00, 'Draft', NOW(), NOW(), 'PO/2025-26/011', '2026-05-26', 3),
(12, 'WO/2025-26/012', 'Priya Kadam', '2026-04-27', '2026-05-11', 'Net 30', 'Retail fixture installation', '', '', NULL, 55000.00, 4950.00, 4950.00, 64900.00, 'Completed', NOW(), NOW(), 'PO/2025-26/012', '2026-05-27', 3),
(13, 'WO/2025-26/013', 'David Chen', '2026-04-29', '2026-05-13', 'Net 45', 'CNC Machine Calibration', '', '', NULL, 8000.00, 720.00, 720.00, 9440.00, 'In Progress', NOW(), NOW(), 'PO/2025-26/013', '2026-05-28', 3),
(14, 'WO/2025-26/014', 'Lata Mangesh', '2026-04-31', '2026-05-15', 'Due end of month', 'Raw material quality check', '', '', NULL, 12000.00, 1080.00, 1080.00, 14160.00, 'Draft', NOW(), NOW(), 'PO/2025-26/014', '2026-05-29', 3),
(15, 'WO/2025-26/015', 'Vikram Batra', '2026-05-02', '2026-05-17', 'Net 30', 'Steel tubing fabrication', 'Follow pharma-grade specs', '', NULL, 35000.00, 3150.00, 3150.00, 41300.00, 'In Progress', NOW(), NOW(), 'PO/2025-26/015', '2026-05-30', 3),
(16, 'WO/2025-26/016', 'Sarah Jenkins', '2026-05-04', '2026-05-19', 'Net 60', 'Consulting strategy execution', '', '', NULL, 75000.00, 6750.00, 6750.00, 88500.00, 'Draft', NOW(), NOW(), 'PO/2025-26/016', '2026-06-01', 3),
(17, 'WO/2025-26/017', 'Amit Shah', '2026-05-06', '2026-05-21', 'Net 15', 'Gearbox alignment', '', '', NULL, 22000.00, 1980.00, 1980.00, 25960.00, 'Completed', NOW(), NOW(), 'PO/2025-26/017', '2026-06-02', 3),
(18, 'WO/2025-26/018', 'Kavita Reddy', '2026-05-08', '2026-05-23', 'Net 30', 'Server rack mounting', 'Secure to reinforced floor', '', NULL, 18000.00, 1620.00, 1620.00, 21240.00, 'In Progress', NOW(), NOW(), 'PO/2025-26/018', '2026-06-03', 3),
(19, 'WO/2025-26/019', 'Manoj Bajpayee', '2026-05-10', '2026-05-25', 'Due end of month', 'Studio lighting rigging', '', '', NULL, 60000.00, 5400.00, 5400.00, 70800.00, 'Draft', NOW(), NOW(), 'PO/2025-26/019', '2026-06-04', 3),
(20, 'WO/2025-26/020', 'Hans Muller', '2026-05-12', '2026-05-27', 'Net 45', 'Licensing documentation review', '', 'NDA required', NULL, 32000.00, 2880.00, 2880.00, 37760.00, 'Completed', NOW(), NOW(), 'PO/2025-26/020', '2026-06-05', 3),
(21, 'WO/2025-26/021', 'Sneha Kapoor', '2026-05-14', '2026-05-29', 'Net 30', 'Motor rewinding', '', '', NULL, 45000.00, 4050.00, 4050.00, 53100.00, 'In Progress', NOW(), NOW(), 'PO/2025-26/021', '2026-06-06', 3),
(22, 'WO/2025-26/022', 'Rohan Das', '2026-05-16', '2026-06-01', 'Net 15', 'Office furniture assembly', 'Assemble after hours', '', NULL, 95000.00, 8550.00, 8550.00, 112100.00, 'Draft', NOW(), NOW(), 'PO/2025-26/022', '2026-06-07', 3),
(23, 'WO/2025-26/023', 'Kenji Sato', '2026-05-18', '2026-06-03', 'Due end of month', 'Robotic arm programming', '', '', NULL, 11000.00, 990.00, 990.00, 12980.00, 'Completed', NOW(), NOW(), 'PO/2025-26/023', '2026-06-08', 3),
(24, 'WO/2025-26/024', 'Pooja Iyer', '2026-05-20', '2026-06-05', 'Net 30', 'Financial ledger review', '', '', NULL, 65000.00, 5850.00, 5850.00, 76700.00, 'In Progress', NOW(), NOW(), 'PO/2025-26/024', '2026-06-09', 3),
(25, 'WO/2025-26/025', 'Gaurav Tiwari', '2026-05-22', '2026-06-07', 'Net 45', 'Pneumatic tool testing', '', '', NULL, 28000.00, 2520.00, 2520.00, 33040.00, 'Draft', NOW(), NOW(), 'PO/2025-26/025', '2026-06-10', 3),
(26, 'WO/2025-26/026', 'Laura Rossi', '2026-05-24', '2026-06-09', 'Net 30', 'CAD design drafting', '', 'Intellectual property terms apply', NULL, 85000.00, 7650.00, 7650.00, 100300.00, 'Completed', NOW(), NOW(), 'PO/2025-26/026', '2026-06-11', 3);

-- --------------------------------------------------------
-- Table structure for table `work_order_items`
-- --------------------------------------------------------
CREATE TABLE `work_order_items` (
  `item_id` int(11) NOT NULL,
  `work_order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `item_detail` varchar(255) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `uom_amount` decimal(10,2) DEFAULT 0.00,
  `uom_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `work_order_items` (`item_id`, `work_order_id`, `product_id`, `item_detail`, `quantity`, `rate`, `discount`, `amount`, `uom_amount`, `uom_description`) VALUES
(1, 1, 1, 'Industrial Bolt', 500, 120.00, 0.00, 60000.00, 0.00, 'pcs'),
(2, 2, 2, 'Steel Plate', 200, 500.00, 0.00, 100000.00, 0.00, 'kg'),
(3, 3, 3, 'Hydraulic Pump', 5, 2500.00, 0.00, 12500.00, 0.00, 'pcs'),
(4, 4, 5, 'Electrical Cable', 1000, 20.00, 0.00, 20000.00, 0.00, 'm'),
(5, 5, 6, 'Aluminium Sheet', 300, 300.00, 0.00, 90000.00, 0.00, 'kg'),
(6, 6, 4, 'Installation Service', 1, 1500.00, 0.00, 1500.00, 0.00, NULL),
(7, 7, 8, 'Plastic Granules', 200.00, 50.00, 0.00, 10000.00, 0.00, 'kg'),
(8, 8, 7, 'Export Consultancy Services', 1.00, 15000.00, 0.00, 15000.00, 0.00, NULL),
(9, 9, 21, 'Textile Loom Maintenance', 10.00, 2500.00, 0.00, 25000.00, 0.00, 'hours'),
(10, 10, 17, 'Audit Preparation', 1.00, 5000.00, 0.00, 5000.00, 0.00, NULL),
(11, 11, 13, 'Warehouse Logistics Optimization', 10.00, 4000.00, 0.00, 40000.00, 0.00, 'hours'),
(12, 12, 11, 'Retail Fixture Installation', 11.00, 5000.00, 0.00, 55000.00, 0.00, 'pcs'),
(13, 13, 12, 'CNC Machine Calibration', 2.00, 4000.00, 0.00, 8000.00, 0.00, 'pcs'),
(14, 14, 19, 'Raw Material Quality Check', 40.00, 300.00, 0.00, 12000.00, 0.00, 'batches'),
(15, 15, 18, 'Steel Tubing Fabrication', 100.00, 350.00, 0.00, 35000.00, 0.00, 'm'),
(16, 16, 16, 'Consulting Strategy Execution', 30.00, 2500.00, 0.00, 75000.00, 0.00, 'hours'),
(17, 17, 20, 'Gearbox Alignment Services', 4.00, 5500.00, 0.00, 22000.00, 0.00, 'pcs'),
(18, 18, 10, 'Server Rack Mounting', 6.00, 3000.00, 0.00, 18000.00, 0.00, 'pcs'),
(19, 19, 16, 'Studio Lighting Rigging', 12.00, 5000.00, 0.00, 60000.00, 0.00, 'hours'),
(20, 20, 24, 'Licensing Documentation Review', 1.00, 32000.00, 0.00, 32000.00, 0.00, NULL),
(21, 21, 23, 'Motor Rewinding', 5.00, 9000.00, 0.00, 45000.00, 0.00, 'pcs'),
(22, 22, 26, 'Office Furniture Assembly', 50.00, 1900.00, 0.00, 95000.00, 0.00, 'pcs'),
(23, 23, 22, 'Robotic Arm Programming', 1.00, 11000.00, 0.00, 11000.00, 0.00, 'project'),
(24, 24, 24, 'Financial Ledger Review', 26.00, 2500.00, 0.00, 65000.00, 0.00, 'hours'),
(25, 25, 25, 'Pneumatic Tool Testing', 14.00, 2000.00, 0.00, 28000.00, 0.00, 'pcs'),
(26, 26, 24, 'CAD Design Drafting', 17.00, 5000.00, 0.00, 85000.00, 0.00, 'hours');

-- --------------------------------------------------------
-- Indexes for dumped tables (kept unchanged)
-- --------------------------------------------------------
-- (Indexes and AUTO_INCREMENT sections are unchanged from original file and are omitted here for brevity but remain present in the final file.)

COMMIT;
